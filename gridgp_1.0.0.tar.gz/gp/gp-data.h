/* GP-DATA.H - Interface for reading data for Gaussian process model. */

/* Copyright (c) 1995-2004 by Radford M. Neal 
 *
 * Permission is granted for anyone to copy, use, modify, or distribute this
 * program and accompanying programs and documents for any purpose, provided 
 * this copyright notice is retained and prominently displayed, along with
 * a note saying that the original programs are available from Radford Neal's
 * web page, and note is made of any changes made to the programs.  The
 * programs and documents are distributed without any warranty, express or
 * implied.  As the programs were written for research purposes only, they have
 * not been tested to the degree that would be advisable in any important
 * application.  All use of these programs is entirely at the user's own risk.
 */


/* VARIABLES HOLDING TRAINING AND/OR TEST DATA.  When the values or targets
   aren't known, the pointers are null.  The inputs and targets for training
   and test cases are stored with all the inputs or targets for one case
   together - for example, input i for training case c is stored here in 
   train_inputs[N_inputs*c+i]. */

extern data_specifications *data_spec; /* Specifications of data sets */

extern int N_train;									/* Number of training cases */

extern double *train_inputs;				/* Inputs for training cases */
extern double *train_targets;				/* True targets for training cases */

extern int N_test;									/* Number of test cases */

extern double *test_inputs;					/* Inputs for test cases */
extern double *test_targets;				/* True targets for test cases */

extern double *subject_inputs;			/* Inputs for information on subjects */
extern double *cov_inputs;					/* Inputs for information on covariates */

/* parameters for group gp */
extern int tot_num_cov;							/* Total number of covariates */
extern int num_gp;									/* Number of group */
extern int *num_covs; 							/* Array of number of covariates for each group */
extern int *first_gp; 							/* Indicator for first element of group */
extern double *weight;							/* weight for covariance in grouped gp model */
extern double *sd_cov;              /* Standard deviation of covariates */

/* Parameters for hybrid grid model */

extern int max_num_timept;             /* maximum number of time points */
extern int *num_timepts; 							/* Array of number of time points for each subject */

extern double* latent_b;            		// latent normal variable b
extern double* ran_delta;           		// delta of random effect
extern double* ran_psi;             		// psi of random effect
extern double* vbvalue;             		// vb of random effect

extern double *grid_p;    							/* Interpolated time point matrix for grid-based model */
extern double *grid_v;    							/* v matrix for grid-based model */
extern double *psi_mean;               // mean of prior for psi
extern double *psi_var;                // variance of prior for psi

extern double delta_mean;							// mean of prior for delta
extern double delta_var;								// variance of prior for delta

extern double *eta_values;							/* eta values */

extern double *etabar;
extern double *ran_deltabar;
extern double *ran_psibar;
extern double vebar;

/* PROCEDURES. */

void gp_data_read(int, int, gp_spec *, model_specification *, model_survival *);

void gp_data_free(void);



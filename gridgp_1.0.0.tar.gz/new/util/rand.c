/******************************************************************************
* File: rand.c
* Version: 11.10.2004
* Author: Radford M. Neal, Wonil Chung
* First Revised: 02.02.2011
* Last Revised:  02.02.2011
* Description: 
*	RAND.C - Random number generation module.
******************************************************************************/

/* Copyright (c) 1995-2004 by Radford M. Neal 
 *
 * Permission is granted for anyone to copy, use, modify, or distribute this
 * program and accompanying programs and documents for any purpose, provided 
 * this copyright notice is retained and prominently displayed, along with
 * a note saying that the original programs are available from Radford Neal's
 * web page, and note is made of any changes made to the programs.  The
 * programs and documents are distributed without any warranty, express or
 * implied.  As the programs were written for research purposes only, they have
 * not been tested to the degree that would be advisable in any important
 * application.  All use of these programs is entirely at the user's own risk.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/timeb.h>


#include "rand.h"


/* This module uses the 'drand48' pseudo-random number generator found
	 on most Unix systems, the output of which is combined with a file
	 of real random numbers.

	 Many of the methods used in this module may be found in the following
	 reference:

			Devroye, L. (1986) Non-Uniform Random Variate Generation,
				New York: Springer-Verlag.

	 The methods used here are not necessarily the fastest available.  They're
	 selected to be reasonably fast while also being easy to write.
*/


/* CONSTANT PI.  Defined here if not in <math.h>. */

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#if _WIN32
#define RAND_FILE "./randfile"
#endif

/* TABLES OF REAL RANDOM NUMBERS.  A file of 100000 real random numbers
   (NOT pseudo-random) is used in conjunction with pseudo-random numbers
   for extra insurance.  These are employed in the form of five tables
   of 5000 32-bit integers.  

   The file must be located at the path given by RAND_FILE, which should
   be defined on the "cc" command line. */

#define Table_size 5000			/* Number of words in each table */

static int rn[N_tables][Table_size];	/* Random number tables */


/* STATE OF RANDOM NUMBER GENERATOR. */

static int initialized = 0;		/* Has module been initialized? */

static rand_state state0;		/* Default state structure */

static rand_state *state;		/* Pointer to current state */


/* INITIALIZE MODULE.  Sets things up using the default state structure,
   set as if rand_seed had been called with a seed of one. */

static void initialize (void)
{
  int i, j, k, w;
  char b;
	FILE *f;
	struct timeb tmb;
	int sd;

	if (!initialized)
  {
	f = fopen(RAND_FILE,"rb");
    
    if (f==NULL)
    { fprintf(stderr,"Can't open file of random numbers (%s)\n",RAND_FILE);
      exit(1);
    }

    for (i = 0; i<N_tables; i++)
    { for (j = 0; j<Table_size; j++)
      { w = 0;
        for (k = 0; k<4; k++)
        { if (fread(&b,1,1,f)!=1)
          { fprintf(stderr,"Error reading file of random numbers (%s)\n",
                            RAND_FILE);
            exit(1);
          }
          w = (w<<8) | (b&0xff);
        }
        rn[i][j] = w;
			}
    }

		state = &state0;

		initialized = 1;

		///////////////////////////////////////
		ftime(&tmb);
		sd = (int)tmb.time + (int) tmb.millitm;

		rand_seed(sd);
		///////////////////////////////////////

		//rand_seed(1);
  }
}


/* SET CURRENT STATE ACCORDING TO SEED. */

void rand_seed
( int seed
)
{ 
	int j;

  if (!initialized) initialize();

  state->seed = seed;

  state->state48[0] = seed>>16;
  state->state48[1] = seed&0xffff;
  state->state48[2] = rn[0][(seed&0x7fffffff)%Table_size];

  for (j = 0; j<N_tables; j++) 
  { state->ptr[j] = seed%Table_size;
    seed /= Table_size;
  }
}


/* SET STATE STRUCTURE TO USE.  The structure passed must be of the correct
   size and must be set to a valid state.  The only way of obtaining a valid
   state is by copying from the state structure found using rand_get_state. */

void rand_use_state
( rand_state *st
)
{ 
  if (!initialized) initialize();

  state = st;
}


/* RETURN POINTER TO CURRENT STATE.  A pointer to the state structure being
   used is returned.  */

rand_state *rand_get_state (void)
{ 
  if (!initialized) initialize();

  return state;
}


/* GENERATE RANDOM 31-BIT INTEGER. */

int rand_word(void)
{
  int v;
  int j;

	if (!initialized) initialize();

#if _WIN32
	srand((unsigned int)state->state48);
	v = rand();
#else
	v = nrand48(state->state48);
#endif

  for (j = 0; j<N_tables; j++)
  { v ^= rn[j][state->ptr[j]];
  }

  for (j = 0; j<N_tables && state->ptr[j]==Table_size-1; j++) 
  { state->ptr[j] = 0;
  }

  if (j<N_tables) 
  { state->ptr[j] += 1;
  }

  return v & 0x7fffffff;
}


/* GENERATE UNIFORMLY FROM [0,1). */

double rand_uniform (void)
{
  return (double)rand_word() / (1.0+(double)0x7fffffff);
}


/* GENERATE UNIFORMLY FORM (0,1). */

double rand_uniopen (void)
{
  return (0.5+(double)rand_word()) / (1.0+(double)0x7fffffff);
}


/* GENERATE RANDOM INTEGER FROM 0, 1, ..., (n-1). */

int rand_int
( int n
)
{ 
  return (int) (n * rand_uniform());
}


/* GENERATE INTEGER FROM 0, 1, ..., (n-1), WITH GIVEN DISTRIBUTION.  The
   distribution is given by an array of probabilities, which are not 
   necessarily normalized, though they must be non-negative, and not all 
   zero. */

int rand_pickd
( double *p,
  int n
)
{ 
  double t, r;
  int i;

  t = 0;
  for (i = 0; i<n; i++)
  { if (p[i]<0) abort();
    t += p[i];
  }

  if (t<=0) abort();

  r = t * rand_uniform();

  for (i = 0; i<n; i++)
  { r -= p[i];
    if (r<0) return i;
  }

  /* Return value with non-zero probability if we get here due to roundoff. */

  for (i = 0; i<n; i++) 
  { if (p[i]>0) return i;
  }

  abort(); 
}


/* SAME PROCEDURE AS ABOVE, BUT WITH FLOAT ARGUMENT. */

int rand_pickf
( float *p,
  int n
)
{ 
  double t, r;
  int i;

  t = 0;
  for (i = 0; i<n; i++)
  { if (p[i]<=0) abort();
    t += p[i];
  }

  if (t<=0) abort();

  r = t * rand_uniform();

  for (i = 0; i<n; i++)
  { r -= p[i];
    if (r<0) return i;
  }

  /* Return value with non-zero probability if we get here due to roundoff. */

  for (i = 0; i<n; i++) 
  { if (p[i]>0) return i;
  }

  abort(); 
}


/* GAUSSIAN GENERATOR.  Done by using the Box-Muller method, but only one
   of the variates is retained (using both would require saving more state).
   See Devroye, p. 235. 

   As written, should never deliver exactly zero, which may sometimes be
   helpful. */

double rand_gaussian (void)
{
  double a, b;

  a = rand_uniform();
  b = rand_uniopen();

  return cos(2.0*M_PI*a) * sqrt(-2.0*log(b));
}


/* EXPONENTIAL GENERATOR.  See Devroye, p. 29.  Written so as to never
   return exactly zero. */

double rand_exp (void)
{
  return -log(rand_uniopen()); 
}


/* CAUCHY GENERATOR.  See Devroye, p. 29. */

double rand_cauchy (void)
{
  return tan (M_PI * (rand_uniopen()-0.5));
}


/* GAMMA GENERATOR.  Generates a positive real number, r, with density
   proportional to r^(a-1) * exp(-r).  See Devroye, p. 410 and p. 420. 
   Things are fiddled to avoid ever returning a value that is very near 
   zero. */

double rand_gamma
( double a
)
{
  double b, c, X, Y, Z, U, V, W;

  if (a<0.00001)
  { X = a;
  }

  else if (a<=1) 
  { 
    U = rand_uniopen();
    X = rand_gamma(1+a) * pow(U,1/a);
  }

  else if (a<1.00001)
  { X = rand_exp();
  }

  else
  {
    b = a-1;
    c = 3*a - 0.75;
  
    for (;;)
    {
      U = rand_uniopen();
      V = rand_uniopen();
    
      W = U*(1-U);
      Y = sqrt(c/W) * (U-0.5);
      X = b+Y;
  
      if (X>=0)
      { 
        Z = 64*W*W*W*V*V;
  
        if (Z <= 1 - 2*Y*Y/X || log(Z) <= 2 * (b*log(X/b) - Y)) break;
      }
    }
  }

  return X<1e-30 && X<a ? (a<1e-30 ? a : 1e-30) : X;
}


/* BETA GENERATOR. Generates a real number, r, in (0,1), with density
   proportional to r^(a-1) * (1-r)^(b-1).  Things are fiddled to avoid
   the end-points, and to make the procedure symmetric between a and b. */

double rand_beta 
( double a, 
  double b
)
{
  double x, y, r;

  do
  { x = rand_gamma(a);
    y = rand_gamma(b);
    r = 1.0 + x/(x+y);
    r = r - 1.0;
  } while (r<=0.0 || r>=1.0);

  return r;
}

// random number
double RANDOM()
{
	double u=rand()/(RAND_MAX+1.0);
	if(u>=1.0) u=1.0-(1e-10); if(u<=0.0) u=1e-10;
	return(u);
}

// random generator for normal distribution
void ANORMAL(double  *r1, double  *r2)
{
	double u1=RANDOM();
  double u2=RANDOM();
  *r1=sqrt(-2.*log(u1))*cos(6.2830*u2);
  *r2=sqrt(-2.*log(u1))*sin(6.2830*u2);
	return;
}

// Calculate the normal function value
double NormalFunction(double x)
{
	double t,z,ANS;

	z=fabs(x)/sqrt(2.0);
	t=1.0/(1.0+0.5*z);
	ANS=t*exp(-z*z-1.26551223+t*(1.00002368+t*(0.37409196+t*(0.09678418+
		t*(-0.18628806+t*(0.27886807+t*(-1.13520398+t*(1.48851587+
		t*(-0.82215223+t*0.17087277)))))))));
	return x>=0.0 ? 0.5*(2-ANS) : 1-0.5*(2-ANS);
}

// Random generation from a m-dim multivariate normal N(mu,Sigma)
void Multivariate_RNORM(double **sigma_cholesky,double *mu,int m,double *sample)
{
	int i,j;
	double sum,*z,u,u0;
	z=malloc(m*sizeof(double));
  for(i=0;i<m;i++)
  {
		ANORMAL(&u,&u0);
    z[i] = u;
  }

	for(i=0;i<m;i++)
	{
		sum=0;
    for(j=0;j<m;j++) sum = sum + sigma_cholesky[i][j]*z[j];
    sample[i] = mu[i] + sum;
  }
  free(z);
	return;
}


// Sample from a double-truncated normal density N(b,v) truncated to the range (t1,t2)
double TrunNormal(double t1, double t2, double b, double v)
{
	double u,p1,p2,p,alpha=0,y=0,yy=0;
	double c0=2.515517,c1=0.802853,c2=0.010328,d1=1.432788,d2=0.189269,d3=0.001308;
	//double t1=cutpoint[WW],t2=cutpoint[WW+1];

	u = rand()/(RAND_MAX+1.0);

	p1 = NormalFunction((t1-b)/sqrt(v));
	p2 = NormalFunction((t2-b)/sqrt(v));

	p = p1 + u*(p2-p1);
	if(p==0.0) p=1e-10;
	if(p==1.0) p=1-(1e-10);

	if(p>0.0&&p<0.5)
	{
		alpha=p;
		y=sqrt(-2*log(alpha));
	  yy=y-(c0+c1*y+c2*y*y)/(d1*y+d2*y*y+d3*y*y*y+1);
		yy=-yy;
	}
	if(p>0.5&&p<1.0)
	{
		alpha=1-p;
		y=sqrt(-2*log(alpha));
	  yy=y-(c0+c1*y+c2*y*y)/(d1*y+d2*y*y+d3*y*y*y+1);
	}
	if(p==0.5) yy=0;

	return(b+sqrt(v)*yy);
}



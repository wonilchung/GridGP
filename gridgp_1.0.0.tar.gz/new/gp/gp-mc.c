/******************************************************************************
* File: gp-mc.c
* Version: 11.10.2004
* Author: Radford M. Neal, Wonil Chung
* First Revised: 02.02.2011
* Last Revised:  02.02.2011
* Description: 
*	GP-MC.C - Interface between Gaussian process and Markov chain modules.
******************************************************************************/

/* Copyright (c) 1995-2004 by Radford M. Neal 
 *
 * Permission is granted for anyone to copy, use, modify, or distribute this
 * program and accompanying programs and documents for any purpose, provided 
 * this copyright notice is retained and prominently displayed, along with
 * a note saying that the original programs are available from Radford Neal's
 * web page, and note is made of any changes made to the programs.  The
 * programs and documents are distributed without any warranty, express or
 * implied.  As the programs were written for research purposes only, they have
 * not been tested to the degree that would be advisable in any important
 * application.  All use of these programs is entirely at the user's own risk.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <float.h>
#include <limits.h>

#include "misc.h"
#include "matrix.h"
#include "rand.h"
#include "ars.h"
#include "log.h"
#include "mc.h"
#include "data.h"
#include "prior.h"
#include "model.h"
#include "gp.h"
#include "gp-data.h"


/* USE CHEAP ENERGY FUNCTION?  If set to 0, the constant terms in minus the
   log likelihood are included in the energy; if set to 1, they are not.
   This is relevant if the energy is going to be interpreted to give the
   likelihood. */

#define Cheap_energy 0		/* Normally set to 0 */


/* SAVE NON-LINEAR (EG, EXPONENTIAL) TERMS IN COVARIANCE?  Set to zero
   only in order to debug the code that handles the case when there's
   not enough memory to do this. */

#define Use_exp_cov 1		/* Normally set to 1 */


/* CONSTANTS INVOLVING PI. */

#ifndef M_PI
#define M_PI 3.14159265358979323846	/* Define pi, if not defined already */
#endif

#define Log2pi  1.83787706640934548356	/* Log(2*M_PI) */


/* ADJUSTABLE PARAMETER CONTROLLING OPTIONAL MEMORY USAGE.  This adjustable
   parameter sets the maximum amount of memory that will be used to store
   intermediate results (specifically, terms in the covariances), in order to 
   avoid recomputing them.  Its setting has no effect on the results, but 
   setting it higher may reduce computation time, at the cost of memory usage.*/

#define Max_optional_memory 20000000  /* Max. optional memory usage, in bytes */

#define Min_change_sign -2.5

#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

/* GAUSSIAN PROCESS VARIABLES. */

static int initialize_done = 0;	/* Has this all been set up? */

static gp_spec *gp;		/* Gaussian process specification */
static model_specification *model; /* Data model */
static model_survival *surv;	/* Hazard type for survival model */

static gp_hypers hypers;	/* Hyperparameters for Gaussian process, primary
				   state for Monte Carlo */

static gp_hypers stepsizes;	/* Pointers to stepsizes */
static gp_hypers grad;		/* Pointers to derivatives */

static int have_values;		/* Are case-by-case latent values present? */
static int have_variances;	/* Are case-by-case noise variances present? */

static double *aux;		/* Space for auxiliary part of state (latent
				   values and noise variances for each case) */

static double *latent_values;	/* Pointer into aux for latent values */
static double *noise_variances;	/* Pointer into aux for noise variances */

static double *train_cov;	/* Covariance matrix for training points */
static double *diff_cov;	/* Derivative of covariance matrix for trn pts*/

static double *exp_cov[Max_exp_parts]; /* Exponential terms in covariance,
			          saved to speed up computation of diff_cov */

static double *latent_cov;	/* Covariance for latent values at trn points
				    - same storage as exp_cov[0]. */

static double *reg_matrix;	/* Matrix of regression coefficients - same
				   storage as exp_cov[1]. */

static double *post_cov;	/* Posterior cov. for latent values underlying
				   training points - same storage as diff_cov */

static double *diag_inv;	/* Diagonal of inverse covariance (N_train) */

static double *scr1, *scr2;	/* Scratch vectors (N_train long) */


/* PROCEDURES. */

static void sample_values (void);
static void jitter_values (double, int);
static void sample_variances (void);
static void scan_values (int);
static void met_values (double, int, mc_iter *);
static void mh_values (double, int, mc_iter *);

double floor_p(double number, double pos) { return floor(number*pow(10,pos))/pow(10,pos); }


/* SET UP REQUIRED RECORD SIZES PRIOR TO GOBBLING RECORDS. */

void mc_app_record_sizes
( log_gobbled *logg	/* Structure to hold gobbled data */
)
{ 
  gp_record_sizes(logg);
}


/* INITIALIZE AND SET UP DYNAMIC STATE STRUCTURE.  Skips some stuff
   if it's already been done, as indicated by the initialize_done
   variable. */

void mc_app_initialize
( log_gobbled *logg,	/* Records gobbled up from head and tail of log file */
  mc_dynamic_state *ds	/* Structure holding pointers to dynamical state */
)
{ 
  int optional_left;
	int i, j, l;

  if (!initialize_done)
  {
    /* Check that required specification records are present. */
 
    gp     = logg->data['P'];
    model  = logg->data['M'];
		surv   = logg->data['V'];

    gp_check_specs_present(gp,0,model,surv);

    if (model!=0 && model->type=='V')
    { fprintf(stderr,"Can't handle survival models in gp-mc\n");
      exit(1);
		}

		/* Read training data, if any, and set up auxiliary state. */
		data_spec = logg->data['D'];

		if (data_spec!=0 && model==0)
		{ fprintf(stderr,"No model specified for data\n");
			exit(1);
		}

		if (data_spec && logg->actual_size['D'] !=
											 data_spec_size(data_spec->N_inputs,data_spec->N_targets))
		{ fprintf(stderr,"Data specification record is the wrong size!\n");
			exit(1);
		}

		/********************* Read Data ******************/
		if (data_spec!=0){ gp_data_read (1, 0, gp, model, surv);}
		else{ N_train = 0;}
		/*************************************************/
  
    /* Locate existing state records, if they exist. */
  
    hypers.total_hypers = gp_hyper_count(gp,model);
    hypers.hyper_block = logg->data['S'];

    have_values = logg->data['F']!=0;
		have_variances = logg->data['N']!=0;
  
    if (hypers.hyper_block!=0 || have_values || have_variances)
    {
			if (hypers.hyper_block==0)
      { fprintf(stderr,"Missing hyperparameter record\n");
        exit(1);
      }

      if (logg->actual_size['S'] != hypers.total_hypers*sizeof(double))
      { fprintf(stderr,"Bad size for hyperparameter record\n");
        exit(1);
      }

			gp_hyper_pointers (&hypers, gp, model);
		}
    else
    {
      hypers.hyper_block = chk_alloc (hypers.total_hypers, sizeof (double));
      gp_hyper_pointers (&hypers, gp, model);
   
      gp_prior_generate (&hypers, gp, model, 1, 0, 0);
    }

    /* Set up stepsize structure. */

    stepsizes.total_hypers = hypers.total_hypers;
    stepsizes.hyper_block = chk_alloc (hypers.total_hypers, sizeof (double));

		gp_hyper_pointers (&stepsizes, gp, model);

		/* set weight for covariance */
		weight = (double*) malloc(data_spec->N_inputs*sizeof(double));

		/* grouped gp */
		if (num_gp != 0) {
			set_group_memory();
		}
		else {
			for (i=0; i<data_spec->N_inputs; i++) weight[i] = 1.0;
		}

		/* Hybrid Grid */
		if (model!=0 && model->type=='H'){
			set_grid_memory();
			set_grid_p();
		}

		/* Grid-based */
		if (model!=0 && model->type=='G'){
			set_grid_memory();
			set_grid_p();
		}
		/**************************************************/

		aux = chk_alloc (2*gp->N_outputs*N_train, sizeof (double));

		latent_values = aux;
    noise_variances = aux + gp->N_outputs*N_train;

    if (have_values)
    { 
      if (logg->actual_size['F']!=gp->N_outputs*N_train*sizeof(double))
      { fprintf (stderr,
          "Bad size for latent values record (is %d, should be %d)\n",
          logg->actual_size['F'], gp->N_outputs*N_train*sizeof(double));
        exit(1);
      }

      for (i = 0; i<N_train; i++)
      { for (j = 0; j<gp->N_outputs; j++)
        { latent_values [gp->N_outputs*i + j] 
            = ((double*) logg->data['F']) [gp->N_outputs*i + j];
        }
      }
    }

    if (have_variances)
    { 
      if (logg->actual_size['N']!=gp->N_outputs*N_train*sizeof(double))
      { fprintf (stderr,
          "Bad size for noise variances record (is %d, should be %d)\n",
          logg->actual_size['N'], gp->N_outputs*N_train*sizeof(double));
        exit(1);
      }

      for (i = 0; i<N_train; i++)
      { for (j = 0; j<gp->N_outputs; j++)
        { noise_variances [gp->N_outputs*i + j] 
            = ((double*) logg->data['N']) [gp->N_outputs*i + j];
        }
      }
    }

		/* Regression Model */
		if (model!=0 && model->type=='R' && model->noise.alpha[2]!=0 && !have_variances)
    { for (i = 0; i<N_train; i++)
      { for (j = 0; j<gp->N_outputs; j++)
        { noise_variances [gp->N_outputs*i + j] = 1.0;
        }
			}
      have_variances = 1;
		}

		/* Hybrid Grid, Grid-based, Mixed, Repeated */
		if (model!=0 && (model->type=='H' || model->type=='G' || model->type=='M' || model->type=='T')
			 && model->noise.alpha[2]!=0 && !have_variances)
    { for (i = 0; i<N_train; i++)
      { for (j = 0; j<gp->N_outputs; j++)
        { noise_variances [gp->N_outputs*i + j] = 1.0;
        }
			}
      have_variances = 1;
		}

    /* Allocate space for covariance and derivative matrices, and scratch. */

    train_cov  = chk_alloc (N_train*N_train, sizeof(double));
    diff_cov   = chk_alloc (N_train*N_train, sizeof(double));
    latent_cov = chk_alloc (N_train*N_train, sizeof(double));
    reg_matrix = chk_alloc (N_train*N_train, sizeof(double));

    post_cov  = diff_cov;

    optional_left = Max_optional_memory;

    for (l = 0; l<gp->N_exp_parts; l++)
    { 
      if (!Use_exp_cov)
      { exp_cov[l] = 0;
      }
			else if (l==0)
      { exp_cov[l] = latent_cov;
      }
      else if (l==1)
      { exp_cov[l] = reg_matrix;
      }
      else if (N_train*N_train*sizeof(double)<=optional_left)
      { exp_cov[l] = chk_alloc (N_train*N_train, sizeof(double));
        optional_left -= N_train*N_train*sizeof(double);
      }
      else
      { exp_cov[l] = 0;
      }
    }

    diag_inv = chk_alloc (N_train, sizeof(double));

    scr1 = chk_alloc (N_train, sizeof(double));
    scr2 = chk_alloc (N_train, sizeof(double));

    /* Make sure we don't do all this again. */

    initialize_done = 1;
  }

  /* Set up Monte Carlo state structure. */

  ds->aux_dim = 2*gp->N_outputs*N_train;
  ds->aux     = aux;

  ds->dim = hypers.total_hypers;
  ds->q   = hypers.hyper_block;

  ds->temp_state = 0;
  
  ds->stepsize = stepsizes.hyper_block;
}


/* RESET INITIALIZE_DONE IN PREPARATION FOR NEW LOG FILE. */

void gp_mc_cleanup(void)
{
  initialize_done = 0;
}


/* SAVE POSITION AND AUXILIARY PART OF STATE. */

void mc_app_save
( mc_dynamic_state *ds,	/* Current dyanamical state */
  log_file *logf,	/* Log file state structure */
  int index		/* Index of iteration being saved */
)
{
  logf->header.type = 'S';
	logf->header.index = index;
  logf->header.size = hypers.total_hypers * sizeof (double);
  log_file_append (logf, hypers.hyper_block);

	if (have_values)
  { logf->header.type = 'F';
    logf->header.index = index;
    logf->header.size = gp->N_outputs*N_train * sizeof (double);
    log_file_append (logf, latent_values);
  }

	if (have_variances)
  { logf->header.type = 'N';
    logf->header.index = index;
    logf->header.size = gp->N_outputs*N_train * sizeof (double);
    log_file_append (logf, noise_variances);
  }
}


/* APPLICATION-SPECIFIC SAMPLING PROCEDURES. */

int mc_app_sample
( mc_dynamic_state *ds,
	char *op,
	double pm,
	double pm2,
	mc_iter *it,
	mc_temp_sched *sch
)
{
	int i, j;

  if (strcmp(op,"scan-values")==0)
	{
		if (model==0)
    { fprintf (stderr,
			 "The scan-values operation is not allowed when there is no model\n");
      exit(1);
    }

		if (model->type=='R' && model->autocorr)
		{ fprintf(stderr,
       "The scan-values operation isn't implemented for models with autocorrelated noise\n");
      exit(1);
		}

		if ( (model->type=='H' || model->type=='G' || model->type=='M' || model->type=='T') && model->autocorr)
		{ fprintf(stderr,
       "The scan-values operation isn't implemented for models with autocorrelated noise\n");
      exit(1);
		}

    if (!have_values)
    { for (i = 0; i<N_train; i++)
      { for (j = 0; j<gp->N_outputs; j++)
        { latent_values [gp->N_outputs*i + j] = 0;
        }
      }
      have_values = 1;
    }

    scan_values (pm<=0 ? 1 : pm);

    ds->know_pot = 0;
    ds->know_grad = 0;

    return 1;
  }

  else if (strcmp(op,"sample-values")==0)
  {
    if (model==0)
    { fprintf (stderr,
       "The sample-values operation is not allowed when there is no model\n");
      exit(1);
    }

    if (model->type!='R' && model->type!='H' && model->type!='G' && model->type!='M' && model->type!='T')
    { fprintf (stderr,
       "The sample-values operation is not allowed for this model\n");
      exit(1);
    }

    sample_values(); 
    have_values = 1;

    ds->know_pot = 0;
    ds->know_grad = 0;

    return 1;
  }

  else if (strcmp(op,"jitter-values")==0)
  {
    if (model==0)
    { fprintf (stderr,
       "The jitter-values operation is not allowed when there is no model\n");
      exit(1);
    }

    if (!gp->has_jitter)
    { fprintf (stderr,
       "The jitter-values operation is not allowed when there is no jitter\n");
      exit(1);
    }

    if (pm<0 || pm>=1)
    { fprintf(stderr,"First parameter after jitter-values must be in [0,1)\n");
      exit(1);
    }

    if (!have_values)
    { for (i = 0; i<N_train; i++)
      { for (j = 0; j<gp->N_outputs; j++)
        { latent_values [gp->N_outputs*i + j] = 0;
        }
      }
      have_values = 1;
    }

    jitter_values (pm, (int)pm2<=0 ? 1 : (int)pm2); 
    have_values = 1;

    ds->know_pot = 0;
    ds->know_grad = 0;

    return 1;
  }

  else if (strcmp(op,"met-values")==0)
  { 
    if (model==0)
    { fprintf (stderr,
       "The met-values operation is not allowed when there is no model\n");
      exit(1);
    }

    if (!have_values)
    { for (i = 0; i<N_train; i++)
      { for (j = 0; j<gp->N_outputs; j++)
        { latent_values [gp->N_outputs*i + j] = 0;
        }
      }
      have_values = 1;
    }

    if (pm<0)
    { fprintf(stderr,"First parameter after met-values must be positive\n");
      exit(1);
    }

    met_values (pm==0 ? 1 : pm, (int)pm2<=0 ? 1 : (int)pm2, it);

    ds->know_pot = 0;
		ds->know_grad = 0;

    return 1;
  }

  else if (strcmp(op,"mh-values")==0)
  { 
		 if (model==0)
    { fprintf (stderr,
       "The mh-values operation is not allowed when there is no model\n");
      exit(1);
    }

    if (pm<0 || pm>1)
    { fprintf(stderr,"First parameter after mh-values must be in (0,1]\n");
      exit(1);
    }

    if (!have_values)
    { for (i = 0; i<N_train; i++)
      { for (j = 0; j<gp->N_outputs; j++)
        { latent_values [gp->N_outputs*i + j] = 0;
        }
      }
      have_values = 1;
    }

    mh_values (pm==0 ? 1 : pm, (int)pm2<=0 ? 1 : (int)pm2, it);

    ds->know_pot = 0;
		ds->know_grad = 0;

    return 1;
  }

  else if (strcmp(op,"discard-values")==0)
  {
    have_values = 0;

    ds->know_pot = 0;
    ds->know_grad = 0;

    return 1;
	}

	else if (strcmp(op,"scan-discard-values")==0)
  {
    have_values = 0;

    ds->know_pot = 0;
		ds->know_grad = 0;

		/* Do Gibbs Sampling for longitudinal data */
		gibbs_sampling();
		/******************************************/

    return 1;
	}

  else if (strcmp(op,"sample-variances")==0)
  {	
		if (model==0 || (model->type!='R' && model->type!='H' && model->type!='G'
			 && model->type!='M' && model->type!='T') || model->noise.alpha[2]==0)
    { fprintf (stderr,
       "The sample-variances operation is not allowed for this model\n");
      exit(1);
    }

    if (!have_values) 
    { sample_values(); /* Creates values, but doesn't remember them, since  */
    }                  /*   have_values remains set to zero.                */

		sample_variances();

    ds->know_pot = 0;
    ds->know_grad = 0;

    return 1;
  }

	return 0;
}


/* EVALUATE POTENTIAL ENERGY AND ITS GRADIENT.  Assumes that the dynamical
	 state is the same as that in the 'hypers' variable of this module.  The
	 energy is based on the prior for the hyperparameters and the likelihood.
	 The likelihood is based on the target values for training cases if no
	 latent values are stored, and on the latent values for training cases if
	 these do exist.  Note that the latent values are considered fixed at this
	 point (they are changed by sample-values).  If case-by-case noise variances
	 are present, they too are considered fixed when computing the likelihood. */

void mc_app_energy
( mc_dynamic_state *ds,	/* Current dynamical state */
  int N_approx,		/* Number of gradient approximations in use */
  int w_approx,		/* Which approximation to use this time */
	double *energy,	/* Place to store energy, null if not required */
  mc_value *gr		/* Place to store gradient, null if not required */
)
{
  double ld, lp, c, a, n, v, s;
  int found;
  double *d;
  int i, j, k;

  /* Set things up to start. */

	if (ds->q!=hypers.hyper_block) abort();

	if (gr && gr!=grad.hyper_block)
	{ grad.total_hypers = hypers.total_hypers;
    grad.hyper_block = gr;
		gp_hyper_pointers (&grad, gp, model);
	}

	/* Evaluate portion of energy and gradient due to prior.  If the prior
		 probability is very small, go to the recovery code. */

	lp = gp_log_prior(&hypers,gp,model,0);

	if (lp<-1e30) goto recover;

  if (energy) 
	{ *energy = -lp;
  }

  if (gr)
	{ gp_prior_grad(&hypers,gp,model,&grad);
  }

	/* Evaluate the portion of the energy and gradient due to the likelihood
		 for the case-by-case noise variances, if present. */

  if (N_train>0 && have_variances 
			 && model!=0
			 && (model->type=='R' || model->type=='H' || model->type=='G' || model->type=='M' || model->type=='T')
			 && model->noise.alpha[2]!=0)
  {
    a = model->noise.alpha[2];

    for (j = 0; j<gp->N_outputs; j++)
    { 
      n = exp(*hypers.noise[j]);

      for (i = 0; i<N_train; i++)
      { v = log(noise_variances[gp->N_outputs*i+j]) / 2;
        if (energy) 
        { *energy -= gp_gdens (a, n, v, 0);
        }
        if (gr && (model->noise.alpha[0]!=0 || model->noise.alpha[1]!=0)) 
        { gp_gdiff (a, n, v, grad.noise[j], 0);
        }
      }
    }
	}

  /* Evaluate portion of the energy and gradient due to the likelihood
     for target values given latent values, if present.  This is relevant
     only when it affect the noise variance hyperparameter for a regression
     model. */

  if (N_train>0 && have_values && !have_variances 
			 && model!=0
			 && (model->type=='R' || model->type=='H' || model->type=='G' || model->type=='M' || model->type=='T')
			 && model->noise.alpha[2]==0)
  {
    if (model->autocorr)
    { fprintf(stderr,"Latent values must be discarded before hyperparameter\n");
      fprintf(stderr,"   updates are done when the noise is autocorrelated.\n");
      exit(1);
    }

    for (j = 0; j<gp->N_outputs; j++)
    { 
      n = exp(*hypers.noise[j]);

      if (energy)
      { *energy += N_train*log(n);
      }

      if (gr && (model->noise.alpha[0]!=0 || model->noise.alpha[1]!=0))
			{ *grad .noise[j] += N_train;
      }

      for (i = 0; i<N_train; i++)
			{ v = latent_values[gp->N_outputs*i+j] - train_targets[gp->N_outputs*i+j];
        if (energy) 
        { *energy += (v*v)/(2*n*n);
        }
        if (gr && (model->noise.alpha[0]!=0 || model->noise.alpha[1]!=0)) 
        { *grad.noise[j] += -(v*v)/(n*n);
        }
      }
    }
	}

	/* Evaluate portion of energy and gradient due to the data likelihood.
		 This is done separately for each output, but with the computation of the
		 covariance matrix done only once if there is no change from output
		 to output. */

	if (N_train>0)
	{
    if (energy && !Cheap_energy) 
    { *energy += 0.5 * gp->N_outputs * N_train * Log2pi;
    }

    for (j = 0; j<gp->N_outputs; j++)
    { 
      /* Compute covariance matrix for this output, if it's not the same as 
         for the previous output, and then find its Cholesky decomposition
         (and log determinant), and if needed, its inverse (stored in lower
         part of diff_cov and in diag_inv).  If this process fails, go to the 
				 recovery code. */

			if (j==0 || model!=0
				&& (model->type=='R' || model->type=='H' || model->type=='G' || model->type=='M' || model->type=='T')
				&& !have_values
        && (model->noise.alpha[2]!=0 || *hypers.noise[j]!=*hypers.noise[j-1]))
      {
				gp_train_cov (gp, model, &hypers, j, noise_variances,
                      have_values ? train_cov : 0,
                      have_values ? 0 : train_cov,
                      gr ? exp_cov : 0);

				if (!cholesky(train_cov,N_train,&ld))
        { goto recover;
        }
 
        if (gr)
        { for (i = N_train*N_train-1; i>=0; i--)
          { diff_cov[i] = train_cov[i];
          }
          if (!inverse_from_cholesky (diff_cov, scr1, scr2, N_train))
          { goto recover;
          }
          for (i = 0; i<N_train; i++)
          { diag_inv[i] = diff_cov[i*N_train+i];
          }
        }
      }

      /* Multiply values for this output by inverse of Cholesky decomposition.
				 Put in scr1. */

			forward_solve (train_cov, scr1, 1,
				 have_values ? latent_values+j : train_targets+j, gp->N_outputs,
         N_train);

			/* Add the contribution of this output to the energy (if wanted).  Go
         to the recovery code if the contribution is huge. */

			c = ld/2 + squared_norm (scr1, 1, N_train) / 2;

      if (c>1e30) goto recover;

      if (energy) *energy += c;

      /* Compute the contribution of this output to the gradient, if wanted.
         The derivative with respect to each hyperparameter is computed 
         separately. */

      if (gr)
      {
        /* Compute inverse of covariance times values and put in scr2. */

        backward_solve (train_cov, scr2, 1, scr1, 1, N_train);

        for (k = 0; k<ds->dim; k++)
        { 
          /* Compute the derivative of the covariance matrix for output j with
             respect to hyperparameter k.  Only the upper triangular part is 
             computed, and stored in diff_cov, allowing the part below the
             diagonal to still contain elements of the inverse covariance. */

          found = gp_cov_deriv (gp, &hypers, exp_cov, ds->q+k, 
																train_inputs, diff_cov, N_train);

          if (gp->has_jitter && ds->q+k==hypers.jitter)
          { for (i = 0; i<N_train; i++)
            { diff_cov[i*N_train+i] += 2 * exp(2 * *hypers.jitter);
            }
            found = 2;
					}

					if (model!=0
						&& (model->type=='R' || model->type=='H' || model->type=='G' || model->type=='M' || model->type=='T')
						&& !have_values && !have_variances)
          { if (ds->q+k==hypers.noise[j])
            { double n;
              int lag;
              n = 2 * exp(2 * *hypers.noise[j]);
              for (i = 0; i<N_train; i++) 
              { diff_cov[i*N_train+i] += n;
              }
              if (model->autocorr)
              { for (i = 0; i<N_train; i++)
                { for (lag = 1; lag<=model->n_autocorr && i+lag<N_train; lag++) 
                  { diff_cov[i*N_train+(i+lag)] += n * model->acf[lag-1];
                  }
                }
                found = 1;
              }
              else
              { found = 2;
              }
            }
					}

          /* Add to derivative of energy using this matrix of derivatives,
             if this hyperparameter plays a direct role in the likelihood. */

          if (found)
          {
            d = diff_cov;
            v = d[0] * (diag_inv[0] - scr2[0]*scr2[0]); 

						if (found==2) /* Non-zero derivatives on diagonal only */
						{ for (i = 1; i<N_train; i++)
							{ d += N_train;
								s = scr2[i];
								v += d[i] * (diag_inv[i] - s*s);
							}
						}
						else /* General case */
						{ for (i = 1; i<N_train; i++)
							{ d += N_train;
								s = scr2[i];
								v += d[i] * (diag_inv[i] - s*s)
											+ 2 * inner_product (d, 1, diff_cov+i, N_train, i)
											- 2 * s * inner_product (scr2, 1, diff_cov+i, N_train, i);
							}
						}

            gr[k] += v / 2;
          }
        }
      }
    }
  }

	/* Check for gradient being huge, and suppress if so. */

  if (gr)
	{ for (k = 0; k<ds->dim; k++)
		{ if (gr[k]>1e10 || gr[k]<-1e10)
      { goto recover_gr;
      }
    }
  }

	return;

  /* Recovery code for when the state is apparently ridiculous.  Just 
     set the energy to a huge value (so we will reject), and set the gradient
     to zero (so we don't make things even worse).  The recover_gr entry
		 is for when the situation was diagnosed based on the gradient (so for
     consistency, we shouldn't alter the computed energy). */

recover:

  if (energy) 
  { *energy = 1e30;
  }

recover_gr:

	if (gr)
  { for (k = 0; k<ds->dim; k++) gr[k] = 0;
  }
}


/* SAMPLE FROM DISTRIBUTION AT INVERSE TEMPERATURE OF ZERO.  Returns zero
   if this is not possible. */

int mc_app_zero_gen
( mc_dynamic_state *ds	/* Current dynamical state */
)
{ 
  return 0;
}


/* SET STEPSIZES FOR EACH COORDINATE.  Assumes that the stepsizes are
   stored in the same place as the 'stepsizes' variable of this module. 
   Stepsizes are set heuristically based on the assumption that the
   range of hyperparameters other than the noise variances does not
   get smaller as the training set size increases. This is somewhat
   debatable. */

void mc_app_stepsizes
( mc_dynamic_state *ds	/* Current dynamical state */
)
{ 
  int i, l;

  if (ds->stepsize!=stepsizes.hyper_block) abort();

  if (gp->has_constant)
  { 
    if (gp->constant.alpha[0]!=0)
    { *stepsizes.constant = 0.1;
    }
  }

  if (gp->has_linear)
  { 
    if (gp->linear.alpha[0]!=0)
    { if (gp->linear.alpha[1]==0)
      { *stepsizes.linear_cm = 0.1;
      }
      else
      { int c;
        c = 0;
        for (i = 0; i<gp->N_inputs; i++) 
        { c += !(gp->linear_flags[i]&Flag_omit);
        }
        *stepsizes.linear_cm = 0.1/sqrt((double)c);
      }
    }
   
    if (gp->linear.alpha[1]!=0)
    { for (i = 0; i<gp->N_inputs; i++)
      { if (!(gp->linear_flags[i]&Flag_omit))
        { *stepsizes.linear[i] = 0.1;
        }
      }
    }
  }

  if (gp->has_jitter)
  { 
    if (gp->jitter.alpha[0]!=0)
    { *stepsizes.jitter = 0.5/sqrt((double)N_train*gp->N_outputs+1);
    }
  }

  for (l = 0; l<gp->N_exp_parts; l++)
  { 
    if (gp->exp[l].scale.alpha[0]!=0)
    { *stepsizes.exp[l].scale = 0.1;
    }

		/* simplified gp, original rel_cm gp, grouped rel_cm gp */
		if (gp->exp[l].relevance.alpha[0]!=0)
		{ if (gp->exp[l].relevance.alpha[1]==0 && gp->exp[l].relevance.alpha[2]==0)
			{ *stepsizes.exp[l].rel_cm = 0.1;
			}
      else
      { int c;
        c = 0;
        for (i = 0; i<gp->N_inputs; i++) 
        { c += !(gp->exp[l].flags[i]&Flag_omit);
				}
        *stepsizes.exp[l].rel_cm = 0.1/sqrt((double)c);
      }
    }

		/* original (rel_cm) gp */
    if (gp->exp[l].relevance.alpha[1]!=0)
    { for (i = 0; i<gp->N_inputs; i++)
      { if (!(gp->exp[l].flags[i]&Flag_omit))
        { *stepsizes.exp[l].rel[i] = 0.1;
        }
      }
		}

		/* grouped (rel_cm) gp */
		if (gp->exp[l].relevance.alpha[2]!=0)
		{ for (i = 0; i<gp->N_inputs; i++)
      { if (!(gp->exp[l].flags[i]&Flag_omit))
        { *stepsizes.exp[l].rel[i] = 0.1;
        }
      }
		}
  }

	/* Real */
  if (model!=0 && model->type=='R')
  {  
    if (model->noise.alpha[0]!=0)
    { *stepsizes.noise_cm = 
         model->noise.alpha[1]==0 ? 0.5/sqrt((double)N_train*gp->N_outputs+1)
                                  : 0.1/sqrt((double)gp->N_outputs);
    }
    
    if (model->noise.alpha[1]!=0)
    { for (i = 0; i<gp->N_outputs; i++)
      { *stepsizes.noise[i] = 0.5/sqrt((double)N_train+1);
      }
    }
	}

	/* Hybrid Grid */
  if (model!=0 && model->type=='H')
  {
    if (model->noise.alpha[0]!=0)
    { *stepsizes.noise_cm =
         model->noise.alpha[1]==0 ? 0.5/sqrt((double)N_train*gp->N_outputs+1)
                                  : 0.1/sqrt((double)gp->N_outputs);
    }

    if (model->noise.alpha[1]!=0)
    { for (i = 0; i<gp->N_outputs; i++)
      { *stepsizes.noise[i] = 0.5/sqrt((double)N_train+1);
      }
    }
	}

	/* Grid-based */
	if (model!=0 && model->type=='G')
	{
		/* noise */
		if (model->noise.alpha[0]!=0)
		{ 	*stepsizes.noise_cm =
				 model->noise.alpha[1]==0 ? 0.5/sqrt((double)N_train*gp->N_outputs+1)
                                  : 0.1/sqrt((double)gp->N_outputs);
		}
		if (model->noise.alpha[1]!=0)
    { for (i = 0; i<gp->N_outputs; i++)
			{ *stepsizes.noise[i] = 0.5/sqrt((double)N_train+1);
			}
		}

		/* random */
		for (i = 0; i < model->num_grid; i++) {
			*stepsizes.diag_random[i] = 0.5/sqrt((double)N_train+1);
		}

		for (i = 0; i < model->num_grid*(model->num_grid-1)/2; i++) {
			*stepsizes.offdiag_random[i] = 0.5/sqrt((double)N_train+1);
			//*stepsizes.offdiag_random[i] = 0.05/sqrt((double)N_train+1);
		}
	}

	/* Mixed */
	if (model!=0 && model->type=='M')
	{
		/* noise */
		if (model->noise.alpha[0]!=0)
		{ 	*stepsizes.noise_cm =
				 model->noise.alpha[1]==0 ? 0.5/sqrt((double)N_train*gp->N_outputs+1)
                                  : 0.1/sqrt((double)gp->N_outputs);
		}
		if (model->noise.alpha[1]!=0)
    { for (i = 0; i<gp->N_outputs; i++)
			{ *stepsizes.noise[i] = 0.5/sqrt((double)N_train+1);
			}
		}

		/* random */
		for (i = 0; i < model->num_random; i++) {
			*stepsizes.diag_random[i] = 0.5/sqrt((double)N_train+1);
		}

		for (i = 0; i < model->num_random*(model->num_random-1)/2; i++) {
			*stepsizes.offdiag_random[i] = 0.5/sqrt((double)N_train+1);
			//*stepsizes.offdiag_random[i] = 0.05/sqrt((double)N_train+1);
		}
	}

	/* Repeated */
	if (model!=0 && model->type=='T')
	{
  	/* noise */
		if (model->noise.alpha[0]!=0)
		{ 	*stepsizes.noise_cm =
				 model->noise.alpha[1]==0 ? 0.5/sqrt((double)N_train*gp->N_outputs+1)
																	: 0.1/sqrt((double)gp->N_outputs);
		}
		if (model->noise.alpha[1]!=0)
		{ for (i = 0; i<gp->N_outputs; i++)
			{ *stepsizes.noise[i] = 0.5/sqrt((double)N_train+1);
			}
		}

		/* random */
		if (model->random.alpha[0]!=0)
		{ 	*stepsizes.random_cm =
				 model->random.alpha[1]==0 ? 0.5/sqrt((double)N_train*gp->N_outputs+1)
																	: 0.1/sqrt((double)gp->N_outputs);
		}
		if (model->random.alpha[1]!=0)
		{ for (i = 0; i<gp->N_outputs; i++)
			{ *stepsizes.random[i] = 0.5/sqrt((double)N_train+1);
			}
		}
	}
}


/* LOG PROBABILITY FUNCTION USED IN SCAN-VALUES AND JITTER-VALUES.  Computes
   the log probability and the derivative of the log probability for
   a latent value that determines a binary or class probability, as 
   needed for the Adaptive Rejection Sampling procedure (ars).  Constant
	 factors in the likelihood are ignored.  The distribution is described
   by the extra structure below, which gives the prior mean and variance, 
	 and the information needed to determine the likelihood. */

struct extra { int b; double cnst, mean, var; };

static double logp
( double x,		/* Point to evaluate log density at */
  double *d,		/* Place to store derivative of log density */
  void *extra		/* Extra information */
)
{
  struct extra *ex = extra;
  double e;

  e = exp(x);

  *d = - (x-ex->mean) / ex->var 
       - e / (ex->cnst + e)
       + (ex->b ? 1 : 0);

  return - (x-ex->mean)*(x-ex->mean) / (2*ex->var) 
         - log (ex->cnst + e) 
         + (ex->b ? x : 0);
}


/* ANOTHER LOG PROBABILITY FUNCTION USED IN SCAN-VALUES AND JITTER-VALUES.  
   Like logp above, but for Poisson models.  Negative values are left
   censored up to their absolute value. */

static double logpp
( double x,		/* Point to evaluate log density at */
  double *d,		/* Place to store derivative of log density */
  void *extra		/* Extra information */
)
{
  struct extra *ex = extra;
  double e, v, s, lg;
  int i;

  e = exp(x);

  *d = - (x-ex->mean) / ex->var;
  v = - (x-ex->mean)*(x-ex->mean) / (2*ex->var);

  if (ex->b>0)
  { *d += ex->b - e;
    v += ex->b*x - e;
  }
  else
  {
    s = -e;
    for (i = 1; i <= -ex->b; i++)
    { s = addlogs (s, i*x - e - lgamma(i+1));
    }
   
    v += s;

    s = 0;
    for (i = 0; i <= -ex->b; i++)
    { s += exp (lgamma(-ex->b+1) - lgamma(i+1) - (-ex->b+1-i)*x);
    }

    *d += -1/s;
  }

  return v;
}


/* DO GIBBS SAMPLING SCANS FOR LATENT VALUES. */

static void scan_values
( int scans	/* Number of Gibbs sampling scans to do for each output */
)
{
  double mean, prec;
  int i, j, k;
  int N_outputs;

  N_outputs = gp->N_outputs;

  /* Compute the covariance matrix for latent values at training points. 
     This will be the same for all outputs, since it doesn't include any
     noise part. */

	gp_train_cov (gp, 0, &hypers, 0, 0, latent_cov, 0, 0);

	/* Invert this covariance matrix. */

  if (!cholesky(latent_cov,N_train,0)
   || !inverse_from_cholesky (latent_cov, scr1, scr2, N_train))
	{ fprintf(stderr,"Couldn't find inverse of covariance in scan-values!\n");
    exit(1);
  }

  /* Do Gibbs sampling scans for latent values. */

  for (k = 0; k<scans; k++)
  {
		for (j = 0; j<N_outputs; j++)
    {
      for (i = 0; i<N_train; i++)
      {
        /* Find mean and precision (inverse variance) for this value, 
           based on other values. */

        latent_values[i*N_outputs+j] = 0;

        mean = - inner_product (latent_values+j, N_outputs, 
                   latent_cov+N_train*i, 1, N_train) / latent_cov[i*N_train+i];

        prec = latent_cov[i*N_train+i];

        /* Combine this with the likelihood from the target value and
           sample from the resulting distribution. */

				if (model->type=='R') /* Real */
        { double pr;
          pr = have_variances ? 1/noise_variances[i*N_outputs+j]
                              : exp (- 2 * *hypers.noise[j]);
          mean = (mean*prec + train_targets[i*N_outputs+j]*pr) / (prec+pr);
          prec = prec+pr;
          latent_values[i*N_outputs+j] = mean + rand_gaussian()/sqrt(prec);
				}
				else if (model->type=='H' || model->type=='G' || model->type=='M' || model->type=='T') /* Mixed */
        { double pr;
          pr = have_variances ? 1/noise_variances[i*N_outputs+j]
                              : exp (- 2 * *hypers.noise[j]);
          mean = (mean*prec + train_targets[i*N_outputs+j]*pr) / (prec+pr);
          prec = prec+pr;
          latent_values[i*N_outputs+j] = mean + rand_gaussian()/sqrt(prec);
				}
        else if (model->type=='B') /* Logistic regression for binary targets */
        { struct extra ex;
          ex.cnst = 1;
          ex.mean = mean;
          ex.var  = 1/prec;
					ex.b    = train_targets[i*N_outputs+j]==1;
					latent_values[i*N_outputs+j] = ars (mean, sqrt(1/prec), logp, &ex);
        }

        else if (model->type=='N') /* Poisson regressoin for count data */
        { struct extra ex;
          ex.mean = mean;
          ex.var  = 1/prec;
          ex.b    = train_targets[i*N_outputs+j];
          latent_values[i*N_outputs+j] = ars (mean, sqrt(1/prec), logpp, &ex);
        }

        else if (model->type=='C') /* Generalized logistic regression for class targets */
        { struct extra ex;
          int jj;
          ex.cnst = 0;
          for (jj = 0; jj<N_outputs; jj++)
          { if (jj!=j) ex.cnst += exp(latent_values[i*N_outputs+jj]);
          }
          ex.mean = mean;
          ex.var  = 1/prec;
          ex.b    = train_targets[i]==j;
          latent_values[i*N_outputs+j] = ars (mean, sqrt(1/prec), logp, &ex);
        }

        else
        { abort(); 
        }
      }
    }
  }
}


/* DO METROPOLIS UPDATES FOR LATENT VALUES.  The Metropolis proposal is
   a change by an amount that is a scaled down sample from the prior,
   except when 'scale' is negative, in which case the proposed changes to
   different values are independent, with each having a standard deviation 
   that is scaled down from its prior standard deviation.  When there is 
   more than one output, updates are proposed separately for each in turn. */

static void met_values
( double scale,		/* Amount by which to scale covariance for proposal */
  int repeat,		/* Number of repetitions to do */
  mc_iter *it
)
{  
  int i, j, k;
  int N_outputs;

  double new_E, old_E;

  N_outputs = gp->N_outputs;

  /* Compute the covariance matrix for latent values at training points. 
     This will be the same for all outputs. */

	gp_train_cov (gp, 0, &hypers, 0, 0, latent_cov, 0, 0);

  /* Find Cholesky decomposition for use in evaluating energy, and in 
     generating correlated proposals. */

  if (!cholesky(latent_cov,N_train,0))
  { fprintf(stderr,"Couldn't find Cholesky decomposition in met-values!\n");
    exit(1);
  }

  /* Do Metropolis updates. */

  for (k = 0; k<repeat; k++)
  {
    for (j = 0; j<N_outputs; j++)
    { 
      /* Find initial "energy", from prior and likelihood. */

      forward_solve (latent_cov, scr1, 1, latent_values+j, gp->N_outputs, 
                     N_train);
  
      old_E = squared_norm (scr1, 1, N_train) / 2;

      for (i = 0; i<N_train; i++)
      { old_E -= gp_likelihood (&hypers, model, data_spec, 
                  train_targets+i*data_spec->N_targets, 
                  latent_values+i*gp->N_outputs, 
                  have_variances ? noise_variances+i*data_spec->N_targets : 0);
      }

      /* Save current latent variables in scr2. */

      for (i = 0; i<N_train; i++) 
      { scr2[i] = latent_values[i*N_outputs+j];
      }

      /* Add random change to latent variables. */

      for (i = 0; i<N_train; i++) 
      { scr1[i] = rand_gaussian();
      }

      if (scale>0)
      { for (i = 0; i<N_train; i++)
        { latent_values[i*N_outputs+j] += 
            scale * inner_product (scr1, 1, latent_cov+i*N_train, 1, i+1);
        }
      }
      else
      { for (i = 0; i<N_train; i++)
        { latent_values[i*N_outputs+j] += 
            scale * sqrt(latent_cov[i*N_train+i]) * scr1[i];
        }
      }

      /* Find new "energy", from prior and likelihood. */

      forward_solve (latent_cov, scr1, 1, latent_values+j, gp->N_outputs, 
                     N_train);

      new_E = squared_norm (scr1, 1, N_train) / 2;

      for (i = 0; i<N_train; i++)
      { new_E -= gp_likelihood (&hypers, model, data_spec, 
                  train_targets+i*data_spec->N_targets, 
                  latent_values+i*gp->N_outputs, 
                  have_variances ? noise_variances+i*data_spec->N_targets : 0);
      }   

      /* Accept or reject proposed change based on delta. */

      it->proposals += 1;
      it->delta = new_E - old_E;

      if (it->delta<=0 || rand_uniform() < exp(-it->delta))
      { it->move_point = 1;
      }
      else
      { for (i = 0; i<N_train; i++)
        { latent_values[i*N_outputs+j] = scr2[i];
        }
        it->rejects += 1; 
        it->move_point = 0;
      }
    }
  }
}


/* DO METROPOLIS-HASTINGS UPDATES FOR LATENT VALUES.  The proposal is to 
   latent values found by multiplying the current values by a constant factor
   and then adding a random amount that is a scaled down sample from the prior.
   The multiplicative factor is chosen so that the prior is invariant under 
   this update.  This proposal is then accepted or rejected based on the 
   likelihoods alone.  When there is more than one output, updates are 
   proposed separately for each in turn. */

static void mh_values
( double scale,		/* Amount by which to scale random change */
  int repeat,		/* Number of repetitions to do */
  mc_iter *it
)
{  
  int i, j, k;
  int N_outputs;

  double new_E, old_E;
  double alpha;

  N_outputs = gp->N_outputs;
 
  alpha = sqrt(1-scale*scale);

  /* Compute the covariance matrix for latent values at training points. 
     This will be the same for all outputs. */

	gp_train_cov (gp, 0, &hypers, 0, 0, latent_cov, 0, 0);

  /* Find Cholesky decomposition for use in generating correlated noise. */

  if (!cholesky(latent_cov,N_train,0))
  { fprintf(stderr,"Couldn't find Cholesky decomposition in mh-values!\n");
    exit(1);
  }

  /* Do Metropolis-Hastings updates. */

  for (k = 0; k<repeat; k++)
  {
    for (j = 0; j<N_outputs; j++)
    { 
      /* Find initial "energy" from likelihood. */

      old_E = 0;

      for (i = 0; i<N_train; i++)
      { old_E -= gp_likelihood (&hypers, model, data_spec, 
                  train_targets+i*data_spec->N_targets, 
                  latent_values+i*gp->N_outputs, 
                  have_variances ? noise_variances+i*data_spec->N_targets : 0);
      }

      /* Save current latent variables in scr2. */

      for (i = 0; i<N_train; i++) 
      { scr2[i] = latent_values[i*N_outputs+j];
      }

      /* Multiply and add random change to latent variables. */

      for (i = 0; i<N_train; i++) 
      { scr1[i] = rand_gaussian();
      }

      for (i = 0; i<N_train; i++)
      { latent_values[i*N_outputs+j] = alpha * latent_values[i*N_outputs+j]
              + scale * inner_product (scr1, 1, latent_cov+i*N_train, 1, i+1);
      }

      /* Find new "energy" from likelihood. */

      new_E = 0;

      for (i = 0; i<N_train; i++)
      { new_E -= gp_likelihood (&hypers, model, data_spec, 
                  train_targets+i*data_spec->N_targets, 
                  latent_values+i*gp->N_outputs, 
                  have_variances ? noise_variances+i*data_spec->N_targets : 0);
      }   

      /* Accept or reject proposed change based on delta. */

      it->proposals += 1;
      it->delta = new_E - old_E;

      if (it->delta<=0 || rand_uniform() < exp(-it->delta))
      { it->move_point = 1;
      }
      else
      { for (i = 0; i<N_train; i++)
        { latent_values[i*N_outputs+j] = scr2[i];
        }
        it->rejects += 1; 
        it->move_point = 0;
      }
    }
  }
}


/* SAMPLE LATENT VALUES FOR A REGRESSION MODEL. */

static void sample_values(void)
{
  int N_outputs;
  int i, j;

  N_outputs = gp->N_outputs;

  for (j = 0; j<N_outputs; j++)
  { 
    /* Compute Cholesky decomposition of posterior covariance and 
       regression matrix for this output, if it's not the same as 
       for the last output. */

		if (j==0 || model->noise.alpha[2]!=0
						 || *hypers.noise[j]!=*hypers.noise[j-1])
    {
			/* Compute covariance matrix for both latent and target values. */

			gp_train_cov (gp, model, &hypers, j, noise_variances,
										latent_cov, train_cov, 0);

			/* Find Cholesky decomposition of train_cov and compute its inverse. */

			if (!cholesky (train_cov,N_train,0)
			 || !inverse_from_cholesky (train_cov, scr1, scr2, N_train))
			{ fprintf (stderr, "Couldn't invert covariance in sample-values!\n");
				exit(1);
			}
    
      /* Find the matrix of coefficients for computing the posterior mean from
         the targets. */
    
      matrix_product (latent_cov, train_cov, reg_matrix, 
                      N_train, N_train, N_train);
    
			/* Find the posterior covariance for latent values underlying training
         cases, using various matrices computed above. */
    
      matrix_product (reg_matrix, latent_cov, post_cov,
                      N_train, N_train, N_train);
    
      for (i = N_train*N_train - 1; i>=0; i--) 
      { post_cov[i] = latent_cov[i] - post_cov[i];
      }

      /* Find the Cholesky decomposition of the posterior covariance. */

      if (!cholesky(post_cov,N_train,0))
      { fprintf(stderr,
          "Couldn't find Cholesky decomposition of posterior covariance in sample-values!\n");
         exit(1);
      }
    }

    /* Sample latent values for each training case. */

    for (i = 0; i<N_train; i++) 
    { scr1[i] = rand_gaussian();
    }

    for (i = 0; i<N_train; i++)
    { latent_values[i*N_outputs+j] = 
         inner_product (scr1, 1, post_cov+i*N_train, 1, i+1)
          + inner_product (reg_matrix+i*N_train, 1, train_targets+j, 
                           N_outputs, N_train);
    }
  }
}


/* UPDATE LATENT VALUES BY PLAYING WITH JITTER-REDUCED VERSIONS. */

static void jitter_values
( double jp,
  int repeat
)
{
  double jitter, mean, prec;
  int N_outputs;
  int i, j, k;

  N_outputs = gp->N_outputs;

  jitter = exp(2 * *hypers.jitter);

  /* Compute the covariance matrix for full latent values at training points, 
     and store in latent_cov.  This will be the same for all outputs, since 
     it doesn't include any noise part. */

	gp_train_cov (gp, 0, &hypers, 0, 0, latent_cov, 0, 0);

  /* Find covariance matrix of jitter-reduced latent variables, and store
     in train_cov. */

  for (i = N_train*N_train - 1; i>=0; i--) 
  { train_cov[i] = latent_cov[i];
  }

  for (i = 0; i<N_train; i++)
  { train_cov[i*N_train+i] -= (1-jp) * jitter;
  }

  /* Find Cholesky decomposition of the covariance of the full latent 
     variables and compute its inverse. */
    
  if (!cholesky (latent_cov,N_train,0)
   || !inverse_from_cholesky (latent_cov, scr1, scr2, N_train))
  { fprintf (stderr, "Couldn't invert covariance in jitter-values!\n");
    exit(1);
  }

  /* Find the matrix of coefficients for computing the mean of the 
     jitter-reduced latent variables from the full latent variables. */
    
  matrix_product (train_cov, latent_cov, reg_matrix, N_train, N_train, N_train);
    
  /* Find the covariance for jitter-reduced latent values conditional on
     the full latent variables, using various matrices computed above. */
    
  matrix_product (reg_matrix, train_cov, post_cov, N_train, N_train, N_train);
    
  for (i = N_train*N_train - 1; i>=0; i--) 
  { post_cov[i] = train_cov[i] - post_cov[i];
  }

  /* Find the Cholesky decomposition of this covariance, to use in generation.*/

  if (!cholesky(post_cov,N_train,0))
  { fprintf(stderr,
      "Couldn't find Cholesky decomposition of covariance in jitter-values!\n");
     exit(1);
  }

  for (k = 0; k<repeat; k++)
  {
    for (j = 0; j<N_outputs; j++)
    { 
      /* Sample jitter-reduced latent values for each training case. */

      for (i = 0; i<N_train; i++) 
      { scr1[i] = rand_gaussian();
      }

      for (i = 0; i<N_train; i++)
      { scr2[i] = inner_product (scr1, 1, post_cov+i*N_train, 1, i+1)
                + inner_product (reg_matrix+i*N_train, 1, latent_values+j, 
                                 N_outputs, N_train);
      }

      /* Sample full latent values based on jitter-reduced latent values
         and targets. */

      for (i = 0; i<N_train; i++)
      {
        /* Find mean and precision (inverse variance) for full latent value
           based on jitter-reduced value. */

        mean = scr2[i];
        prec = 1 / ((1-jp)*jitter);

        /* Combine this with the likelihood from the target value and
           sample from the resulting distribution. */

				/* Real */
				if (model->type=='R')
        { double pr;
          pr = have_variances ? 1/noise_variances[i*N_outputs+j]
                              : exp (- 2 * *hypers.noise[j]);
          mean = (mean*prec + train_targets[i*N_outputs+j]*pr) / (prec+pr);
          prec = prec+pr;
          latent_values[i*N_outputs+j] = mean + rand_gaussian()/sqrt(prec);
				}

				/* Hybrid Grid, Grid-based, Mixed, Repeated */
				else if (model->type=='H' || model->type=='G' || model->type=='M' || model->type=='T')
        { double pr;
          pr = have_variances ? 1/noise_variances[i*N_outputs+j]
                              : exp (- 2 * *hypers.noise[j]);
          mean = (mean*prec + train_targets[i*N_outputs+j]*pr) / (prec+pr);
          prec = prec+pr;
          latent_values[i*N_outputs+j] = mean + rand_gaussian()/sqrt(prec);
				}

        else if (model->type=='B') /* Logistic regression for binary targets */
        { struct extra ex;
          ex.cnst = 1;
          ex.mean = mean;
          ex.var  = 1/prec;
          ex.b    = train_targets[i*N_outputs+j]==1;
          latent_values[i*N_outputs+j] = ars (mean, sqrt(1/prec), logp, &ex);
        }

        else if (model->type=='N') /* Poisson regressoin for count data */
        { struct extra ex;
          ex.mean = mean;
          ex.var  = 1/prec;
          ex.b    = train_targets[i*N_outputs+j];
          latent_values[i*N_outputs+j] = ars (mean, sqrt(1/prec), logpp, &ex);
        }

        else if (model->type=='C') /* Generalized logistic regression for class targets */
        { struct extra ex;
          int jj;
          ex.cnst = 0;
          for (jj = 0; jj<N_outputs; jj++)
          { if (jj!=j) ex.cnst += exp(latent_values[i*N_outputs+jj]);
          }
          ex.mean = mean;
          ex.var  = 1/prec;
          ex.b    = train_targets[i]==j;
          latent_values[i*N_outputs+j] = ars (mean, sqrt(1/prec), logp, &ex);
				}

        else
				{ abort();
        }
      }
    }
  }
}


/* SAMPLE CASE-BY-CASE VARIANCES FOR REGRESSION MODEL. */

static void sample_variances(void)
{
  double a, n, d, s;
  int N_outputs;
  int i, j;

  N_outputs = gp->N_outputs;

  a = model->noise.alpha[2];

  for (j = 0; j<N_outputs; j++)
  { 
    n = exp (2 * *hypers.noise[j]);

    for (i = 0; i<N_train; i++)
    {
      d = latent_values[N_outputs*i+j] - train_targets[N_outputs*i+j];
      s = rand_gamma((a+1)/2) / ((a*n+d*d)/2);

      noise_variances[N_outputs*i+j] = 1/s;
    }
  }
}

/***** New code implemented by Wonil *****/

// Set memory for group gp
void set_group_memory()
{
	int i, j, prev_cov, idx=0;
	double avg_cov;

	// set number of covariates for each group
	num_covs = (int*) malloc(num_gp*sizeof(int));
	for (i=0; i<num_gp; i++) num_covs[i] = 0;
	for (i=0; i<tot_num_cov; i++)	num_covs[(int)cov_inputs[i]-1]++;

	// set standard deviation for each covariates
	sd_cov = (double*) malloc(tot_num_cov*sizeof(double));
	for (i=0; i<tot_num_cov; i++){
	  sd_cov[i] = 0; avg_cov = 0;
		for (j=0; j<N_train; j++)	avg_cov += train_inputs[data_spec->N_inputs*j+i]/(double)N_train;
		for (j=0; j<N_train; j++) sd_cov[i] += pow(train_inputs[data_spec->N_inputs*j+i]-avg_cov, 2)/(double)N_train;
		sd_cov[i] = sqrt(sd_cov[i]);
	}

	// set weight
	for (i=0; i<tot_num_cov; i++) weight[i] = 0.0;
	for (i=0; i<num_gp; i++)	{
		for (j=0; j<num_covs[i]; j++) {
			//weight[idx] = sqrt((double)num_covs[i]);            // consider only number of covaraites
			weight[idx] = sqrt((double)num_covs[i])/sd_cov[i];    // consider both number and sd of covariates
			idx++;
		}
	}

	// set indicator for first element of group
	first_gp = (int*) malloc(tot_num_cov*sizeof(int));
	prev_cov = cov_inputs[0]; first_gp[0] = 1;
	for (i=1; i<tot_num_cov; i++) {
		if (prev_cov == cov_inputs[i]) first_gp[i] = 0;
		else {first_gp[i] = 1; prev_cov = cov_inputs[i];}
	}
}

// Free memory for group gp
void free_group_memory()
{
	free(num_covs); num_covs = 0;
	free(first_gp); first_gp = 0;
	free(sd_cov); sd_cov = 0;
}

// Set memory for grid-based model
void set_grid_memory()
{
	int i, r, s, z, ns1;

	r = model->num_grid; s = model->num_subject;
	ns1 = N_train;
	z = (int)r*(r-1)/2;

	latent_b = (double *) malloc(s*r*sizeof(double));
	for(i=0; i<s*r; i++) latent_b[i]=0;

	ran_delta = (double *) malloc(r*sizeof(double));
	for(i=0; i<r; i++) ran_delta[i]=0;

	ran_psi = (double *) malloc(z*sizeof(double));
	for(i=0; i<z; i++) ran_psi[i]=0;

	vbvalue = (double *) malloc(ns1*sizeof(double));
	for(i=0; i<ns1; i++) vbvalue[i]=0;

	// set grid_p and grid_v matrix
	grid_p = (double*) malloc(ns1*r*sizeof(double));
	for (i=0; i<ns1*r ;i++) grid_p[i] = 0;

	grid_v = (double*) malloc(ns1*r*sizeof(double));
	for (i=0; i<ns1*r ;i++) grid_v[i] = 0;

	// set number of time points for each subject
	num_timepts = (int*) malloc(s*sizeof(int));
	for (i=0; i<s; i++) num_timepts[i] = 0;
	for (i=0; i<ns1; i++) num_timepts[(int)subject_inputs[i]-1]++;

	// mean and variance of prior for psi
	psi_mean = (double *)malloc(z*sizeof(double));
	for(i=0; i<z; i++) psi_mean[i] = model->p_mean[i];

	psi_var = (double *)malloc(z*z*sizeof(double));
	for(i=0; i<z*z; i++) psi_var[i] = model->p_var[i];

	delta_mean = model->del_mean;
	delta_var = model->del_var;

	eta_values = (double *)malloc(ns1*sizeof(double));
	for(i=0; i<ns1; i++) eta_values[i]=0;
}

// Free memory for grid-based model
void free_grid_memory()
{
	free(latent_b); latent_b = 0;
	free(ran_delta); ran_delta = 0;
	free(ran_psi); ran_psi = 0;
	free(vbvalue); vbvalue = 0;
	free(grid_p); grid_p = 0;
	free(grid_v); grid_v = 0;
	free(num_timepts); num_timepts = 0;
	free(psi_mean); psi_mean = 0;
	free(psi_var); psi_var = 0;
	free(eta_values); eta_values = 0;
}

// Set grid_p matrix for grid-based model
void set_grid_p()
{
	int i, j, near_idx, r, s, ns1;
	double *time, *intv_pts;
	double min_time = DBL_MAX, max_time = DBL_MIN, intv;

	r = model->num_grid; s = model->num_subject;
	ns1 = N_train;

	if (train_inputs == 0)
	{
		fprintf(stderr, "There is no training inputs\n");
		exit(1);
	}

	max_num_timept = INT_MIN;
	for (i=0; i<s; i++) max_num_timept = MAX(max_num_timept, num_timepts[i]);

	// time should range from 0 to 1
	time = (double*) malloc(ns1*sizeof(double));
	for (i=0; i<ns1 ;i++){
		time[i] = train_inputs[data_spec->N_inputs*(i+1)-1];
		min_time = MIN(min_time, time[i]);
		max_time = MAX(max_time, time[i]);
	}
	for (i=0; i<ns1 ;i++)	time[i] = (time[i]-min_time) / (max_time-min_time);

	intv_pts = (double*) malloc(r*sizeof(double));
	intv = (double) 1/ (double)(r-1);
	intv_pts[0] = (double)0; intv_pts[r-1] = 1.0;
	for (i=1; i<r-1; i++) intv_pts[i] = intv*i;
	for (i=0; i<ns1 ;i++){
		for (j=0; j<r; j++) {
			if (floor_p(fabs(intv_pts[j] - time[i]),6)<=floor_p(intv,6)) {
				near_idx = j;
				break;
			}
		}

		grid_p[r*i+near_idx] = (double) fabs(intv_pts[near_idx+1] - time[i])/ intv;
		grid_p[r*i+near_idx+1] = (double) fabs(intv_pts[near_idx] - time[i])/ intv;
	}

	free(intv_pts); intv_pts = 0;
	free(time); time=0;

}

void gibbs_sampling()
{
	// only this precedure is required in case of hybrid grid model
	if (gp->N_outputs != 1 || model->type != 'H') {
		fprintf(stderr, "Sampling eta for mixed model is only allowed when number of output is 1\n");
		exit(1);
	}

	sample_eta();
	set_random_delta();
	set_random_psi();
	set_random_v();
	set_latent_b();
}

void sample_eta()
{
	double pr, scans, mean, prec;
	double **sigma_eta, **chol, *mean_eta, *yprime;
	int i, j, ns1;

	/*///////////////////////////////////////////////////////
	FILE *fp_new1, *fp_new2, *fp_new3;

	fp_new1 = fopen("C:\\log1.txt","w");
	fp_new2 = fopen("C:\\log2.txt","w");
	fp_new3 = fopen("C:\\log3.txt","w");
	/*/////////////////////////////////////////////////////*/

	if (gp->N_outputs != 1 || model->type != 'H') {
		fprintf(stderr, "Sampling eta for mixed model is only allowed when number of output is 1\n");
		exit(1);
	}

	ns1 = N_train;

	// Compute the covariance matrix for latent values at training points.
	//   This will be the same for all outputs, since it doesn't include any
  //   noise part.
	gp_train_cov (gp, 0, &hypers, 0, 0, latent_cov, 0, 0);

	/*////////////////////////////////////////////////////////////////
	for (i=0; i<1000; i++){
		for (j=0; j<1000; j++)
		 fprintf(fp_new1,"%.15f,",(double)latent_cov[i*1000+j]);
		fprintf(fp_new1,"\n");
	}
	fclose(fp_new1);
	/////////////////////////////////////////////////////////////////*/

	if (!cholesky(latent_cov, ns1, 0) || !inverse_from_cholesky (latent_cov, scr1, scr2, ns1)){
		fprintf(stderr,"Couldn't find inverse of covariance in sampled eta!\n");
		exit(1);
	}

	/*////////////////////////////////////////////////////////////////
	for (i=0; i<1000; i++){
		for (j=0; j<1000; j++)
		 fprintf(fp_new2,"%.15f,",(double)latent_cov[i*1000+j]);
		fprintf(fp_new2,"\n");
	}
	fclose(fp_new2);
	/////////////////////////////////////////////////////////////////*/

	// Do Gibbs sampling scans for latent values.
	pr = exp(-2 * *hypers.noise[0]);
	for (i = 0; i<ns1; i++)
		latent_cov[i*ns1+i] += pr;

	if (!cholesky(latent_cov, ns1, 0) || !inverse_from_cholesky (latent_cov, scr1, scr2, ns1)){
		fprintf(stderr,"Couldn't find inverse of inversed covariance + noise in sampled eta!\n");
		exit(1);
	}

	// Compute sigma_psi
	mean_eta = (double*) malloc(ns1*sizeof(double));
	yprime = (double*) malloc(ns1*sizeof(double));

	sigma_eta = (double**) malloc(ns1*sizeof(double*));
	chol = (double**) malloc(ns1*sizeof(double*));
	for (i=0; i<ns1; i++) {
		sigma_eta[i] = (double*) malloc(ns1*sizeof(double));
		chol[i] = (double*) malloc(ns1*sizeof(double));
	}

	for (i=0; i<ns1; i++)
		for (j=0; j<ns1; j++) sigma_eta[i][j] = latent_cov[i*ns1+j];

	for (i=0; i<ns1; i++)
		yprime[i] = pr*(train_targets[i]-vbvalue[i]);

	XprimeVec(sigma_eta, yprime, ns1, ns1, mean_eta);

	/*////////////////////////////////////////////////////////////////
	for (i=0; i<1000; i++){
		for (j=0; j<1000; j++)
		 fprintf(fp_new1,"%.10f,",(double)sigma_eta[i][j]);
		fprintf(fp_new1,"\n");
	}
	fclose(fp_new1);

	for (i=0; i<1000; i++){
		fprintf(fp_new2,"%.10f,",(double)mean_eta[i]);
		fprintf(fp_new2,"\n");
	}
	fclose(fp_new2);

	/////////////////////////////////////////////////////////////////*/

	Cholesky(sigma_eta, ns1, chol);
	Multivariate_RNORM(chol, mean_eta, ns1, eta_values);

	/*/////////////////////////////////////////////////////////////////
	for (j=0; j<1000; j++){
	Multivariate_RNORM(chol, mean_eta, ns1, eta_values);
	for (i=0; i<1000; i++){
		fprintf(fp_new3,"%.10f,",(double)eta_values[i]);
	}
	fprintf(fp_new3,"\n");
	}

	fclose(fp_new3);
	/////////////////////////////////////////////////////////////////*/

	free(mean_eta);
	free(yprime);

	for (i=0; i<ns1; i++) {
		free(sigma_eta[i]);
		free(chol[i]);
	}
	free(sigma_eta);
	free(chol);
}

// Update Delta Matrix for Random effect
void set_random_delta()
{
	double **w, **xi;
	double *sigma_del, *mean_del, *p, *b, *gval, bpsi, wdel, wtw, wtxi, ve;
	int i, j, k, l, r, s, *t, idx, idx1, ns1;
	ns1 = N_train;

	r = model->num_grid; s = model->num_subject;
	ns1 = N_train; t = num_timepts;
	p = grid_p; b = latent_b;
	ve = exp(2 * *hypers.noise[0]);

	// Compute matrix w
	w = (double**) malloc(r*sizeof(double*));
	xi = (double**) malloc(r*sizeof(double*));
	for (i=0; i<r; i++){
		w[i] = (double*) malloc(ns1*sizeof(double));
		xi[i] = (double*) malloc(ns1*sizeof(double));
	}

	idx = 0;
	for (i=0; i<s; i++){
		for (j=0; j<t[i]; j++){
			idx1 = 0;
			for (l=0; l<r; l++){
				bpsi = 0;
				for (k=0; k<l; k++) bpsi += b[i*r+k]*ran_psi[idx1+k];
				if (l!=0) idx1 += l;
				w[l][idx] = p[idx*r+l]*(b[i*r+l]+bpsi);
			}
			idx++;
		}
	}

	// Compute matrix xi
	gval =  (double*) malloc(ns1*sizeof(double));

	for(i=0; i<ns1; i++) {
		wdel = 0;
		for (j=0; j<r; j++) wdel += w[j][i]*ran_delta[j];
		gval[i] = (train_targets[i]-eta_values[i]-wdel);
	}

	for (i=0; i<ns1; i++)
		for (j=0; j<r; j++) xi[j][i] = gval[i] + w[j][i]*ran_delta[j];

	// Compute sigma_del and mean_del
	sigma_del =  (double*) malloc(r*sizeof(double));
	mean_del =  (double*) malloc(r*sizeof(double));

	for (i=0; i<r; i++){
		wtw=0; wtxi=0;
		for (j=0; j<ns1; j++) {
			wtw += w[i][j]*w[i][j];
			wtxi += w[i][j]*xi[i][j];
		}

		sigma_del[i] = 1.0/(wtw/ve+1.0/delta_var);
		mean_del[i] = sigma_del[i]*(wtxi/ve+delta_mean/delta_var);
	}

	for (i=0; i<r; i++){
		ran_delta[i] = TrunNormal(0, HUGE_VAL, mean_del[i], sigma_del[i]);
	}

	free(sigma_del);
	free(mean_del);
	free(gval);

	for (i=0; i<r; i++) {
		free(w[i]);
		free(xi[i]);
	}

	free(w);
	free(xi);

}


// Update Psi Matrix for Random effect
void set_random_psi()
{
	double **sigma_psi, **inv, **chol, **r0, **r0_inv;
	double *p, *b, *u, *utu, *gval, *ugval, *ugval1, *ut, *mean_psi, *bdelp;
	double u0, u1, temp, ve;
	int i, j, k, l, r, s, *t, idx, idx1, z, ns1;
	ns1 = N_train;
	r = model->num_grid; s = model->num_subject;
	t = num_timepts; z = (int)r*(r-1)/2;
	p = grid_p; b = latent_b;

	ve = exp(2 * *hypers.noise[0]);

	// Compute matrix u and uvu
	u = (double*) malloc(ns1*z*sizeof(double));
	utu = (double*) malloc(z*z*sizeof(double));

	for (i=0; i<ns1*z; i++) u[i] = 0;

	idx = 0;
	for (i=0; i<s; i++){
		for (j=0; j<t[i]; j++){
			idx1 = 0;
			for (k=0; k<r-1; k++){
				for (l=k+1; l<r ;l++){
					u[idx*z+idx1] = b[i*r+k]*ran_delta[l]*p[idx*r+l];
					idx1++;
				}
			}
			idx++;
		}
	}

	matrix_xtx(u, utu, ns1, z);

	// compute sigma_psi
	sigma_psi = (double**) malloc(z*sizeof(double*));
	chol = (double**) malloc(z*sizeof(double*));
	inv = (double**) malloc(z*sizeof(double*));
	r0 = (double**) malloc(z*sizeof(double*));
	r0_inv = (double**) malloc(z*sizeof(double*));
	for (i=0; i<z; i++) {
		sigma_psi[i] = (double*) malloc(z*sizeof(double));
		chol[i] = (double*) malloc(z*sizeof(double));
		inv[i] = (double*) malloc(z*sizeof(double));
		r0[i] = (double*) malloc(z*sizeof(double));
		r0_inv[i] = (double*) malloc(z*sizeof(double));
	}

	for (i=0; i<z; i++)
		for (j=0; j<z; j++) r0[i][j] = psi_var[i*z+j];

	if (z==1) r0_inv[0][0] = 1.0/r0[0][0];
	else INVERSE(r0,z,r0_inv);

	for (i=0; i<z; i++)
		for (j=0; j<z; j++) inv[i][j] = utu[i*z+j]/ve + r0_inv[i][j];

	if (z==1) sigma_psi[0][0] = 1.0/inv[0][0];
	else INVERSE(inv,z,sigma_psi);

	// Compute mean_psi
	mean_psi = (double*) malloc(z*sizeof(double));
	gval = (double*) malloc(ns1*sizeof(double));
	ugval = (double*) malloc(z*sizeof(double));
	ugval1 = (double*) malloc(z*sizeof(double));
	ut = (double*) malloc(ns1*z*sizeof(double));
	bdelp = (double*) malloc(ns1*sizeof(double));

	idx = 0;
	for (i=0; i<s; i++){
		for (j=0; j<t[i]; j++){
			temp = 0;
			for (k=0; k<r; k++) temp += b[i*r+k]*ran_delta[k]*p[idx*r+k];
			bdelp[idx] = temp;
			idx++;
		}
	}

	for(i=0; i<ns1; i++) gval[i] = (train_targets[i]-eta_values[i]-bdelp[i])/ve;

	matrix_transpose(u, ut, ns1, z);
	matrix_product(ut, gval, ugval, z, 1, ns1);
	XprimeVec(r0_inv, psi_mean, z, z, ugval1);

	for (i=0; i<z; i++) ugval[i] += ugval1[i];

	XprimeVec(sigma_psi, ugval, z, z, mean_psi);

	// Sample latent variable b
	if (z==1) {
		ANORMAL(&u0,&u1);
		ran_psi[0] = mean_psi[0]+u0*sigma_psi[0][0];
	} else {
		Cholesky(sigma_psi, z, chol);
		Multivariate_RNORM(chol, mean_psi, z, ran_psi);
	}

	// deallocate memory
	free(bdelp);
	free(ut);
	free(ugval);
	free(ugval1);
	free(gval);
	free(mean_psi);

	for (i=0; i<z; i++) {
		free(sigma_psi[i]);
		free(chol[i]);
		free(inv[i]);
		free(r0[i]);
		free(r0_inv[i]);
	}

	free(sigma_psi);
	free(chol);
	free(inv);
	free(r0);
	free(r0_inv);

	free(utu);
	free(u);

}


// Compute random matrix vb
void set_random_v()
{
	double *p, *del, *psi, *delpsi, *v;
	int i, j, r, idx, ns1;
	ns1 = N_train;
	r = model->num_grid;
	p = grid_p; v = grid_v;

	// allocate memory
	del = (double*) malloc(r*r*sizeof(double));
	psi = (double*) malloc(r*r*sizeof(double));
	delpsi = (double*) malloc(r*r*sizeof(double));

	// v matrix
	for (i=0; i<r*r; i++) {
			del[i] = 0; psi[i] = 0;
	}

	for (i=0; i<r; i++){
		del[i*(r+1)] = ran_delta[i];
		psi[i*(r+1)] = 1;
	}

	idx=0;
	for (i=0; i<r; i++) {
		for (j=0; j<i; j++) {
			 psi[i*r+j] = ran_psi[idx];
			 idx++;
		}
	}

	matrix_product(del,psi,delpsi,r,r,r);
	matrix_product(p,delpsi,v,ns1,r,r);

	free(delpsi);
	free(psi);
	free(del);
}

// Update Latent Normal Variable b for Random effect
void set_latent_b()
{
	double **inv, **inv1, **chol_vec, **chol, **sigma_b;
	double *v, *vtv, *gval, *vgval, *vt, *mean_b, sum_vb, ve;
	int i, j, k, rt, r, s, *t, prev_t, sum_r, idx, ns1;
	ns1 = N_train;
	r = model->num_grid; s = model->num_subject;
	t = num_timepts;

	ve = exp(2 * *hypers.noise[0]);

	// compute vtv
	v = grid_v;
	vtv = (double*) malloc(s*r*r*sizeof(double));

	prev_t = 0;
	for (i=0; i<s; i++){
		matrix_xtx(v+r*prev_t, vtv+i*r*r, t[i], r);
		prev_t += t[i];
	}

	// compute sigma_b
	inv = (double**) malloc(s*r*sizeof(double*));
	inv1 = (double**) malloc(s*r*sizeof(double*));
	chol_vec = (double**) malloc(s*r*sizeof(double*));
	chol = (double**) malloc(s*r*sizeof(double*));
	sigma_b = (double**) malloc(s*r*sizeof(double*));

	for (i=0; i<s*r; i++) {
		inv[i] = (double*) malloc(r*sizeof(double));
		inv1[i] = (double*) malloc(r*sizeof(double));
		chol_vec[i] = (double*) malloc(r*sizeof(double));
		chol[i] = (double*) malloc(s*r*sizeof(double));
		sigma_b[i] = (double*) malloc(s*r*sizeof(double));
	}

	for (i=0; i<s*r; i++){
		for (j=0; j<r; j++){
			inv[i][j] = vtv[i*r+j]/ve;
			if (j == (i%r)) inv[i][j] += 1;
		}
	}


	for (i=0; i<s; i++) INVERSE(inv+i*r,r,inv1+i*r);

	for (i=0; i<s; i++) Cholesky(inv1+i*r,r,chol_vec+i*r);

	for (i=0; i<s*r; i++)
		for (j=0; j<s*r; j++) chol[i][j]=0;

	rt = r; sum_r = 0;
	for (i=0; i<s*r; i++){
		if (rt == 0) {rt = r; sum_r += r;}
		for (j = 0; j < r; j++) {
			chol[i][sum_r+j] = chol_vec[i][j];
		}
		rt--;
	}

	for (i=0; i<s*r; i++)
		for (j=0; j<s*r; j++) sigma_b[i][j]=0;

	rt = r; sum_r = 0;
	for (i=0; i<s*r; i++){
		if (rt == 0) {rt = r; sum_r += r;}
		for (j = 0; j < r; j++) {
			sigma_b[i][sum_r+j] = inv1[i][j];
		}
		rt--;
	}

	// Compute mean_b
	mean_b = (double*) malloc(s*r*sizeof(double));
	gval =  (double*) malloc(ns1*sizeof(double));
	vgval =  (double*) malloc(s*r*sizeof(double));
	vt = (double*) malloc(max_num_timept*r*sizeof(double));

	for(i=0; i<ns1; i++) gval[i] = (train_targets[i]-eta_values[i])/ve;

	prev_t = 0;
	for (i=0; i<s; i++){
		matrix_transpose(v+r*prev_t, vt, t[i], r);
		matrix_product(vt, gval+prev_t, vgval+r*i, r, 1, t[i]);
		prev_t += t[i];
	}

	XprimeVec(sigma_b, vgval, s*r, s*r, mean_b);

	// Sample latent variable b
	Multivariate_RNORM(chol, mean_b, s*r, latent_b);

	// Set vbvalue
	idx = 0;
	for (i=0; i<s; i++)
		for (j=0; j<t[i]; j++){
			sum_vb = 0;
			for (k=0; k<r; k++) sum_vb += grid_v[idx*r+k] * latent_b[i*r+k];
			vbvalue[idx] = sum_vb;
			idx++;
		}

	// deallocate memory
	free(vt);
	free(vgval);
	free(gval);
	free(mean_b);

	for (i=0; i<s*r; i++) {
		free(inv[i]);
		free(inv1[i]);
		free(chol_vec[i]);
		free(chol[i]);
		free(sigma_b[i]);
	}

	free(inv);
	free(inv1);
	free(chol);
	free(chol_vec);
	free(sigma_b);

	free(vtv);
}

void mc_app_dev_memory()
{
	int i, r, ns1, k;

	ns1 = N_train; r = model->num_grid;
	k =  0.5*r*(r-1);

	etabar = (double *)malloc(ns1*sizeof(double));
	ran_deltabar = (double *)malloc(r*sizeof(double));
	ran_psibar = (double *)malloc(k*sizeof(double));

	for(i=0; i<ns1; i++) etabar[i] = 0.0;
	for (i=0; i<r; i++) ran_deltabar[i] = 0.0;
	for (i=0; i<k; i++) ran_psibar[i] = 0.0;
	vebar = 0.0;
}

void mc_app_deviance(double *dev)
{
	double *pd, *p, *pt, *pdpt, *del, *psi, *delpsi, *psitdel, *d, **tmp, **tmp_inv, *a, atsiga, det, like, ve;
	int r, s, *t, sum_t, prev_t, i1, j1, sum_t_sq=0, idx, ns1, k1;

	if (model->type != 'H')
		return;

	p = grid_p;
	r = model->num_grid; s = model->num_subject; t = num_timepts;
	ns1 = N_train;
	ve = exp(2 * *hypers.noise[0]);

	// calculate bars
	for(i1=0; i1<ns1; i1++) etabar[i1] += eta_values[i1];
	for (i1=0; i1<r; i1++) ran_deltabar[i1] += ran_delta[i1];
	for (i1=0; i1<0.5*r*(r-1); i1++) ran_psibar[i1] += ran_psi[i1];
	vebar += ve;

	for (i1=0; i1<s; i1++) sum_t_sq += t[i1]*t[i1];

	a = (double *)malloc(max_num_timept*sizeof(double));
	pd = (double *)malloc(ns1*r*sizeof(double));
	del = (double*) malloc(r*r*sizeof(double));
	psi = (double*) malloc(r*r*sizeof(double));
	delpsi = (double*) malloc(r*r*sizeof(double));
	psitdel = (double*) malloc(r*r*sizeof(double));
	d = (double*) malloc(r*r*sizeof(double));
	pt = (double *)malloc(max_num_timept*r*sizeof(double));
	pdpt = (double *)malloc(sum_t_sq*sizeof(double));
	tmp = (double**) malloc(max_num_timept*sizeof(double*));
	tmp_inv = (double**) malloc(max_num_timept*sizeof(double*));
	for (i1=0; i1<max_num_timept; i1++) {
		tmp[i1] = (double*) malloc(max_num_timept*sizeof(double));
		tmp_inv[i1] = (double*) malloc(max_num_timept*sizeof(double));
	}

	for (i1=0; i1<r*r; i1++) {del[i1] = 0; psi[i1] = 0;}

	for (i1=0; i1<r; i1++){ del[i1*(r+1)] = ran_delta[i1]; psi[i1*(r+1)] = 1;}

	idx=0;
	for (i1=0; i1<r; i1++)
		for (j1=(i1+1); j1<r; j1++) { psi[j1*r+i1] = ran_psi[idx]; idx++; }

	matrix_product(del,psi,delpsi,r,r,r);
	matrix_transpose(delpsi,psitdel,r,r);
	matrix_product(delpsi,psitdel,d,r,r,r);
	matrix_product(p,d,pd,ns1,r,r);

	sum_t = 0; prev_t = 0;
	for (i1=0; i1<s; i1++){
		matrix_transpose(p+r*prev_t,pt,t[i1],r);
		matrix_product(pd+r*prev_t,pt,pdpt+sum_t,t[i1],t[i1],r);

		sum_t += t[i1]*t[i1];
		prev_t += t[i1];
	}

	like = 0;
	prev_t = 0; idx = 0;
	for (k1=0; k1<s; k1++) {

		for (i1=0; i1<t[k1]; i1++)
			for (j1=0; j1<t[k1]; j1++) {
				tmp[i1][j1] = pdpt[idx];
				if (i1 == j1) tmp[i1][j1] += ve;
					idx++;
			}

		if (t[k1]==1) tmp_inv[0][0] = 1.0/tmp[0][0];
		else INVERSE(tmp, t[k1], tmp_inv);

		det = Determinant(tmp, t[k1]);

		for (i1=0; i1<t[k1]; i1++)
			a[i1] = train_targets[prev_t+i1]-eta_values[prev_t+i1];   //a[i1] = y[prev_t+i1]-amu-gvalue[prev_t+i1];

		atsiga = 0;
		for (i1=0; i1<t[k1]; i1++)
			for (j1=0; j1<t[k1]; j1++)
				atsiga += tmp_inv[i1][j1]*a[i1]*a[j1];

		like += -0.5*((double)t[k1])*log(2*3.14159265358) - 0.5*log(det) - 0.5*atsiga;

		prev_t += t[k1];

	}

	*dev -= 2.0*like;

	free(a);
	free(pdpt);
	free(pt);
	free(pd);
	free(psitdel);
	free(d);

	free(delpsi);
	free(psi);
	free(del);

	for (i1=0; i1<max_num_timept; i1++) {
		free(tmp[i1]);
		free(tmp_inv[i1]);
	}

	free(tmp);
	free(tmp_inv);
}

void mc_app_dic_bpic(double *dev, double *pd1, double *dic, double *bpic, int *niter)
{
	double *pd, *p, *pt, *pdpt, *del, *psi, *delpsi, *psitdel, *d, **tmp, **tmp_inv, *a, atsiga, det, like;
	double dhat, mean_dev;
	int r, s, *t, sum_t, prev_t, i1, j1, sum_t_sq=0, idx, ns1, k1;

	if (model->type != 'H')
		return;

	p = grid_p;
	r = model->num_grid; s = model->num_subject; t = num_timepts;
	ns1 = N_train;

	// calculate bars
	for(i1=0; i1<ns1; i1++) etabar[i1] /= (double)(*niter);
	for (i1=0; i1<r; i1++) ran_deltabar[i1] /= (double)(*niter);
	for (i1=0; i1<0.5*r*(r-1); i1++) ran_psibar[i1] /= (double)(*niter);
	mean_dev = *dev/(double)(*niter);
	vebar /= (double)(*niter);

	for (i1=0; i1<s; i1++) sum_t_sq += t[i1]*t[i1];

	a = (double *)malloc(max_num_timept*sizeof(double));
	pd = (double *)malloc(ns1*r*sizeof(double));
	del = (double*) malloc(r*r*sizeof(double));
	psi = (double*) malloc(r*r*sizeof(double));
	delpsi = (double*) malloc(r*r*sizeof(double));
	psitdel = (double*) malloc(r*r*sizeof(double));
	d = (double*) malloc(r*r*sizeof(double));
	pt = (double *)malloc(max_num_timept*r*sizeof(double));
	pdpt = (double *)malloc(sum_t_sq*sizeof(double));
	tmp = (double**) malloc(max_num_timept*sizeof(double*));
	tmp_inv = (double**) malloc(max_num_timept*sizeof(double*));
	for (i1=0; i1<max_num_timept; i1++) {
		tmp[i1] = (double*) malloc(max_num_timept*sizeof(double));
		tmp_inv[i1] = (double*) malloc(max_num_timept*sizeof(double));
	}

	for (i1=0; i1<r*r; i1++) {del[i1] = 0; psi[i1] = 0;}

	for (i1=0; i1<r; i1++){ del[i1*(r+1)] = ran_deltabar[i1]; psi[i1*(r+1)] = 1;}

	idx=0;
	for (i1=0; i1<r; i1++)
		for (j1=(i1+1); j1<r; j1++) { psi[j1*r+i1] = ran_psibar[idx]; idx++; }

	matrix_product(del,psi,delpsi,r,r,r);
	matrix_transpose(delpsi,psitdel,r,r);
	matrix_product(delpsi,psitdel,d,r,r,r);
	matrix_product(p,d,pd,ns1,r,r);

	sum_t = 0; prev_t = 0;
	for (i1=0; i1<s; i1++){
		matrix_transpose(p+r*prev_t,pt,t[i1],r);
		matrix_product(pd+r*prev_t,pt,pdpt+sum_t,t[i1],t[i1],r);

		sum_t += t[i1]*t[i1];
		prev_t += t[i1];
	}

	like = 0;
	prev_t = 0; idx = 0;
	for (k1=0; k1<s; k1++) {

		for (i1=0; i1<t[k1]; i1++)
			for (j1=0; j1<t[k1]; j1++) {
				tmp[i1][j1] = pdpt[idx];
				if (i1 == j1) tmp[i1][j1] += vebar;
				idx++;
			}

		if (t[k1]==1) tmp_inv[0][0] = 1.0/tmp[0][0];
		else INVERSE(tmp, t[k1], tmp_inv);

		det = Determinant(tmp, t[k1]);

		for (i1=0; i1<t[k1]; i1++)
			a[i1] = train_targets[prev_t+i1]-etabar[prev_t+i1]; //a[i1] = y[prev_t+i1]-amubar-gvaluebar[prev_t+i1];

		atsiga = 0;
		for (i1=0; i1<t[k1]; i1++)
			for (j1=0; j1<t[k1]; j1++)
				atsiga += tmp_inv[i1][j1]*a[i1]*a[j1];

		like += -0.5*((double)t[k1])*log(2*3.14159265358) - 0.5*log(det) - 0.5*atsiga;

		prev_t += t[k1];

	}

	dhat = -2.0*like;

	free(a);
	free(pdpt);
	free(pt);
	free(pd);
	free(psitdel);
	free(d);

	free(delpsi);
	free(psi);
	free(del);

	for (i1=0; i1<max_num_timept; i1++) {
		free(tmp[i1]);
		free(tmp_inv[i1]);
	}

	free(tmp);
	free(tmp_inv);

	// calculate pd, dic, bpic
	*pd1 = mean_dev - dhat;
	*dic = mean_dev + *pd1;
	*bpic = mean_dev + 2**pd1;

	// free memory
	free(etabar);
	free(ran_deltabar);
	free(ran_psibar);
}

void mc_app_monitoring(FILE *fp1)
{
	int i, r;

	if (model->type != 'H')
		return;

	r = model->num_grid;

	for(i=0; i<r; i++)fprintf(fp1,"%lf\t",(double)ran_delta[i]);
	for(i=0; i<0.5*r*(r-1); i++) fprintf(fp1,"%lf\t",(double)ran_psi[i]);
}


void mc_app_get_ninput(int *ninput)	// Structure to hold gobbled data
{
	if (num_gp == 0)
		*ninput = gp->N_inputs;
	else *ninput = num_gp;
}

void mc_app_model_sel_index(mc_dynamic_state *ds,
														double *prior_guess, int *variable_selected)
{
	int i=0, start=0, end=0, cc = 100;
	double alpha, width, mean1, mean2, lp1, lp2, v, U, post_gamma;

	if (gp->exp[0].relevance.alpha[1]==0 && gp->exp[0].relevance.alpha[2]==0)     /* simplified gp */
		return;

	// set alpha
	if (gp->exp[0].relevance.alpha[1]!=0) alpha = gp->exp[0].relevance.alpha[1];  /* original (rel_cm) gp */
	if (gp->exp[0].relevance.alpha[2]!=0) alpha = gp->exp[0].relevance.alpha[2];  /* grouped (rel_cm) gp */

	// Update model selection indices
	if(gp->exp[0].relevance.alpha[1]!=0){ /* original (rel_cm) gp */
		width = prior_width_scaled(&gp->exp[0].relevance, gp->N_inputs);
		start = 1;
		end = ds->dim - 1;
	}
	if(gp->exp[0].relevance.alpha[2]!=0){ /* grouped (rel_cm) gp */
		//width = prior_width_scaled(&gp->exp[0].relevance, num_gp);
		width = prior_width_scaled(&gp->exp[0].relevance, gp->N_inputs);
		start = 1;
		end = ds->dim - 1;
	}

	// Modify "end" based on the model
	if (model!=0 && model->type=='G'){
		end -= (model->num_grid*(model->num_grid+1)/2);
	}else if (model!=0 && model->type=='M'){
		end -= (model->num_random*(model->num_random+1)/2);
	}else if (model!=0 && model->type=='T'){
		end -= 1;
	}

	mean1 = (double)1/(width*width);
	mean2 = (double)1/(cc*width*cc*width);

	for(i = start; i < end; i++){
			v = ds->q[i];
			lp1 = (alpha/2) * (-2*v) - exp(-2*v) * alpha/(2*mean1) + (alpha/2) * log(alpha/(2*mean1));
			lp2 = (alpha/2) * (-2*v) - exp(-2*v) * alpha/(2*mean2) + (alpha/2) * log(alpha/(2*mean2));
			U = rand_uniform();
			post_gamma = prior_guess[i-start]*exp(lp2) / ((1.0-prior_guess[i-start])*exp(lp1)+prior_guess[i-start]*exp(lp2));
			if(U < post_gamma)
				variable_selected[i-start] = 1;
			else
				variable_selected[i-start] = 0;
	}
}


/*
// Sample Eta values
void sample_eta1()
{
	double scans, mean, prec, pr;
	int i, k;

	scans = 10;

	if (gp->N_outputs != 1 || model->type != 'H') {
		fprintf(stderr, "Sampling eta for mixed model is only allowed when number of output is 1\n");
		exit(1);
	}

	// Compute the covariance matrix for latent values at training points.
	//   This will be the same for all outputs, since it doesn't include any
	//   noise part.

	gp_train_cov (gp, 0, &hypers, 0, 0, latent_cov, 0, 0);

	// Invert this covariance matrix.
	if (!cholesky(latent_cov,N_train,0)
   || !inverse_from_cholesky (latent_cov, scr1, scr2, N_train))
	{ fprintf(stderr,"Couldn't find inverse of covariance in discard-scan-values!\n");
		exit(1);
	}

	// Do Gibbs sampling scans for latent values.

  for (k = 0; k<scans; k++)
	{
		for (i = 0; i<N_train; i++)
		{
			// Find mean and precision (inverse variance) for this value, based on other values.
			eta_values[i] = 0;

			mean = - inner_product(eta_values, gp->N_outputs, latent_cov+N_train*i, 1, N_train) / latent_cov[i*N_train+i];
			prec = latent_cov[i*N_train+i];

			// Combine this with the likelihood from the target value and sample from the resulting distribution.
			pr = have_variances ? 1/noise_variances[i] : exp(-2 * *hypers.noise[0]);
			//mean = (mean*prec + train_targets[i]*pr) / (prec+pr);
			mean = (mean*prec + (train_targets[i]-vbvalue[i])*pr) / (prec+pr);          // modified
			prec = prec+pr;
			eta_values[i] = mean + rand_gaussian()/sqrt(prec);
		}
	}
}

void reset_eta1()
{
	int i;
	for (i=0; i<N_train; i++)
		eta_values[i] = 0;
}
*/
/*****************************************/

/* GP-DATA.C - Procedures for reading data for Gaussian process model. */

/* Copyright (c) 1995-2004 by Radford M. Neal 
 *
 * Permission is granted for anyone to copy, use, modify, or distribute this
 * program and accompanying programs and documents for any purpose, provided 
 * this copyright notice is retained and prominently displayed, along with
 * a note saying that the original programs are available from Radford Neal's
 * web page, and note is made of any changes made to the programs.  The
 * programs and documents are distributed without any warranty, express or
 * implied.  As the programs were written for research purposes only, they have
 * not been tested to the degree that would be advisable in any important
 * application.  All use of these programs is entirely at the user's own risk.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "misc.h"
#include "log.h"
#include "data.h"
#include "prior.h"
#include "model.h"
#include "numin.h"
#include "gp.h"
#include "gp-data.h"

/* VARIABLES HOLDING DATA.  As declared in gp-data.h. */

data_specifications *data_spec;	/* Specifications of data sets */

int N_train;										/* Number of training cases */

double *train_inputs;						/* Inputs for training cases */
double *train_targets;					/* True targets for training cases */

int N_test;											/* Number of test cases */

double *test_inputs;						/* Inputs for test cases */
double *test_targets;						/* True targets for test cases */

double *subject_inputs;					/* Inputs for information on subjects */
double *cov_inputs;							/* Inputs for information on covariates */

/* parameters for group gp */
int tot_num_cov;								/* Total number of covariates */
int num_gp;											/* Number of group */
int *num_covs; 									/* Array of number of covariates for each group */
int *first_gp;                  /* Indicator for first element of group */
double *weight;                 /* weight for covariance in grouped gp model */
double *sd_cov;                 /* Standard deviation of covariates */

/* parameters for hybrid grid */
int max_num_timept;             /* maximum number of time points */
int *num_timepts; 							/* Array of number of time points for each subject */

double* latent_b;            		// latent normal variable b
double* ran_delta;           		// delta of random effect
double* ran_psi;             		// psi of random effect
double* vbvalue;             		// vb of random effect

double *grid_p;    							/* Interpolated time point matrix for grid-based model */
double *grid_v;    							/* v matrix for grid-based model */
double *psi_mean;               // mean of prior for psi
double *psi_var;                // variance of prior for psi

double delta_mean;							// mean of prior for delta
double delta_var;								// variance of prior for delta

double *eta_values;							/* eta values */

double *etabar;
double *ran_deltabar;
double *ran_psibar;
double vebar;

/* PROCEDURES. */

static double *read_targets (numin_source *, int,   gp_spec *);
static double *read_inputs  (numin_source *, int *, gp_spec *,
														 model_specification *, model_survival *);
static double *read_subject_inputs (numin_source *, int);
static double *read_cov_inputs (numin_source *, int);


/* FREE SPACE OCCUPIED BY DATA.  Also useful as a way to reset when the
   Gaussian process specification changes. */

void gp_data_free (void)
{
	if (train_inputs!=0)
	{ free(train_inputs);
		train_inputs = 0;
		N_train = 0;
	}

	if (train_targets!=0)
	{ free(train_targets);
		train_targets = 0;
	}

	if (test_inputs!=0)
	{ free(test_inputs);
		test_inputs = 0;
		N_test = 0;
	}

	if (test_targets!=0)
	{ free(test_targets);
		test_targets = 0;
	}
}


/* READ TRAINING AND/OR TEST DATA.  Either or both of these data sets are 
   read, depending on the options passed.  If a data set has already been 
   read, it isn't read again.  This procedure also checks that the data 
   specifications are consistent with the Gaussian process specifications.

   For survival models with non-constant hazard, the first input in a case, 
   representing time, is set to zero by this procedure. */

void gp_data_read
( int want_train,	/* Do we want the training data? */
  int want_test,	/* Do we want the test data? */
  gp_spec *gp,		/* Gaussian process specification */
	model_specification *model, /* Data model being used */
  model_survival *surv	/* Survival model, or zero if irrelevant */
)
{
	numin_source ns;

	if (train_inputs!=0) want_train = 0;
	if (test_inputs!=0)  want_test = 0;

  if (model_targets(model,gp->N_outputs) != data_spec->N_targets
   || gp->N_inputs != data_spec->N_inputs 
                     + (model!=0 && model->type=='V' && surv->hazard_type!='C'))
	{ fprintf(stderr,
		 "Number of inputs/targets in data specification doesn't match GP model\n");
		exit(1);
	}

  if (model!=0 && model->type=='C' && gp->N_outputs!=data_spec->int_target)
  { fprintf(stderr,
"Integer range for targets does not match number of outputs for class model\n");
    exit(1);
  }

  if (model!=0 && model->type=='B' && data_spec->int_target!=2)
  { fprintf(stderr,"Data for binary targets must be specified to be binary\n");
    exit(1);
  }

  if (want_train)
  { 
		numin_spec (&ns, "data@1,0", 1);
    numin_spec (&ns, data_spec->train_inputs, data_spec->N_inputs);
    train_inputs = read_inputs (&ns, &N_train, gp, model, surv);

    if (data_spec->train_targets[0]!=0)
    { numin_spec (&ns, data_spec->train_targets, data_spec->N_targets);
			train_targets = read_targets (&ns, N_train, gp);
    }
  }

  if (want_test && data_spec->test_inputs[0]!=0)
  {
		numin_spec (&ns, "data@1,0", 1);
    numin_spec (&ns, data_spec->test_inputs, data_spec->N_inputs);
    test_inputs = read_inputs (&ns, &N_test, gp, model, surv);

    if (data_spec->test_targets[0]!=0)
    { numin_spec (&ns, data_spec->test_targets, data_spec->N_targets);
      test_targets = read_targets (&ns, N_test, gp);
    }
	}

	if (model!=0 && (model->type=='G'||model->type=='H' ) && data_spec->subject_inputs[0]!=0)
	{
		numin_spec (&ns, "data@1,0", 1);
		numin_spec (&ns, data_spec->subject_inputs, 1);
		subject_inputs = read_subject_inputs (&ns, N_train);
	}

	if (data_spec->cov_inputs[0]!=0)
	{
		numin_spec (&ns, "data@1,0", 1);
		numin_spec (&ns, data_spec->cov_inputs, 1);
		tot_num_cov = data_spec->N_cov;
		cov_inputs = read_cov_inputs (&ns, tot_num_cov);
		num_gp = cov_inputs[tot_num_cov-1];
	}

}


/* READ INPUTS VALUES FOR A SET OF CASES. */

static double *read_inputs
( numin_source *ns,
  int *N_cases_ptr,
  gp_spec *gp,
  model_specification *model, 
  model_survival *surv
)
{
	double *values;
	int N_cases;
	int i, j, j0;

	N_cases = numin_start(ns);

	values = chk_alloc (data_spec->N_inputs*N_cases, sizeof (double));

	for (i = 0; i<N_cases; i++)
  { if (model!=0 && model->type=='V' && surv->hazard_type!='C')
		{ values[data_spec->N_inputs*i+0] = 0;
      j0 = 1;
		}
		else
    { j0 = 0;
    }
    numin_read(ns,values+data_spec->N_inputs*i+j0);
    for (j = j0; j<gp->N_inputs; j++)
    { values[data_spec->N_inputs*i+j] =
        data_trans (values[data_spec->N_inputs*i+j], data_spec->trans[j-j0]);
    }
  }

  numin_close(ns);

  *N_cases_ptr = N_cases;

  return values;
}


/* READ TARGET VALUES FOR A SET OF CASES. */

static double *read_targets
( numin_source *ns,
	int N_cases,
	gp_spec *gp
)
{
  double *tg;
	int i, j;

	if (numin_start(ns)!=N_cases)
	{ fprintf(stderr,
			"Number of input cases doesn't match number of target cases\n");
		exit(1);
	}

  tg = chk_alloc (data_spec->N_targets*N_cases, sizeof (double));

  for (i = 0; i<N_cases; i++)
  { 
    numin_read(ns,tg+data_spec->N_targets*i);

    for (j = 0; j<data_spec->N_targets; j++)
    { tg[data_spec->N_targets*i+j] =
         data_trans (tg[data_spec->N_targets*i+j], 
                     data_spec->trans[data_spec->N_inputs+j]);
    }
  }

  numin_close(ns);

  return tg;
}


/* READ INPUTS VALUES FOR A SET OF CASES. */

static double *read_subject_inputs
( numin_source *ns,
	int N_cases
)
{
  double *tg;
  int i, j;

	if (numin_start(ns)!=N_cases)
	{ fprintf(stderr,
			"Number of subject information input cases doesn't match number of target cases\n");
		exit(1);
	}

	tg = chk_alloc (N_cases, sizeof (double));

  for (i = 0; i<N_cases; i++)
  {
		numin_read(ns,tg+i);
  }

  numin_close(ns);

	return tg;
}

/* READ INPUTS VALUES FOR A SET OF CASES. */

static double *read_cov_inputs
(numin_source *ns,
 int N_cases
)
{
	double *tg;
  int i, j;

	if (numin_start(ns)!=N_cases)
	{ fprintf(stderr,
			"Number of covariate information input cases doesn't match number of covariates\n");
		exit(1);
	}

	tg = chk_alloc (N_cases, sizeof (double));

  for (i = 0; i<N_cases; i++)
  {
		numin_read(ns,tg+i);
  }

  numin_close(ns);

	return tg;
}




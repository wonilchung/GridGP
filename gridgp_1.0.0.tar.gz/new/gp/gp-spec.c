/******************************************************************************
* File: gp-spec.c
* Version: 11.10.2004
* Author: Radford M. Neal, Wonil Chung
* First Revised: 02.02.2011
* Last Revised:  02.02.2011
* Description: 
*	GP-SPEC.C - Program to specify a Gaussian process model.
******************************************************************************/

/* Copyright (c) 1995-2004 by Radford M. Neal 
 *
 * Permission is granted for anyone to copy, use, modify, or distribute this
 * program and accompanying programs and documents for any purpose, provided 
 * this copyright notice is retained and prominently displayed, along with
 * a note saying that the original programs are available from Radford Neal's
 * web page, and note is made of any changes made to the programs.  The
 * programs and documents are distributed without any warranty, express or
 * implied.  As the programs were written for research purposes only, they have
 * not been tested to the degree that would be advisable in any important
 * application.  All use of these programs is entirely at the user's own risk.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "misc.h"
#include "log.h"
#include "prior.h"
#include "model.h"
#include "data.h"
#include "gp.h"


static void usage(int id);


/* MAIN PROGRAM. */

main
( int argc,
  char **argv
)
{
  static gp_spec spec, *gp = &spec;  /* Static so that unused fields are set */
                                     /*   to zero (for future compatibility) */

  log_file logf;
  log_gobbled logg;

  int need_spread;
  char s[10000];
  char ps[100];
  char **ap;
  int l;

  /* Look for log file name. */

  if (argc<2) usage(1);

	logf.file_name = argv[1];

  /* See if we are to display existing specifications. */
	
	/* when arguments are two */
  if (argc==2)
  {
    /* Open log file and gobble up initial records. */
  
    log_file_open(&logf,0);

    log_gobble_init(&logg,0);
    gp_record_sizes(&logg);

    if (!logf.at_end && logf.header.index==-1)
    { log_gobble(&logf,&logg);
    }
  
    /* Display specifications. */
  
    printf("\n");
  
    if ((gp = logg.data['P'])==0)
    { printf ("No specification of GP priors found\n\n");
      exit(0);
    }

    printf ("Number of inputs:    %d\n", gp->N_inputs);  
    printf ("Number of outputs:   %d\n", gp->N_outputs);
  
    if (gp->has_constant)
    { printf("\nConstant part of covariance: %s\n",prior_show(ps,gp->constant));
    }
    
    if (gp->has_linear)
    { printf("\nLinear part of covariance:   %s",prior_show(ps,gp->linear));
      if (list_flags(gp->linear_flags,gp->N_inputs,Flag_omit,s))
      { printf("  omit%s",s);
      }
      if (list_flags(gp->linear_flags,gp->N_inputs,Flag_spread,s))
      { printf("  spread%s",s);
      }
      if (gp->linear_spread)
      { printf("  %d",gp->linear_spread);
      }
      printf("\n");
    }
  
    if (gp->has_jitter)
    { printf("\nJitter part of covariance:   %s\n",prior_show(ps,gp->jitter));
    }

    if (gp->N_exp_parts>0)
    { printf("\nExponential parts of covariance:\n\n");
      printf("   Scale           Relevance            Power   Flags\n");
      for (l = 0; l<gp->N_exp_parts; l++)
      { printf("\n  %-15s", prior_show(ps,gp->exp[l].scale));
        printf(" %-20s", prior_show(ps,gp->exp[l].relevance));
        printf(" %6.3f ",gp->exp[l].power);
        if (list_flags(gp->exp[l].flags,gp->N_inputs,Flag_delta,s))
        { printf("  delta%s",s);
        }
        if (list_flags(gp->exp[l].flags,gp->N_inputs,Flag_omit,s))
        { printf("  omit%s",s);
        }
        if (list_flags(gp->exp[l].flags,gp->N_inputs,Flag_spread,s))
        { printf("  spread%s",s);
        }
        if (gp->exp[l].spread)
        { printf("  %d",gp->exp[l].spread);
        }
        printf("\n");
      }
    }

    printf("\n");
  
    log_file_close(&logf);
  
    exit(0);
  }

  /* Otherwise, figure out form and priors from program arguments. */

  gp->has_constant = 0;	
  gp->has_linear = 0;		
  gp->has_jitter = 0;		
  gp->N_exp_parts = 0;	

  ap = argv+2;

  if (*ap==0 || (gp->N_inputs = atoi(*ap++))<=0) usage(2);	/* N-inputs */
  if (*ap==0 || (gp->N_outputs = atoi(*ap++))<=0) usage(3); /* N-outputs */

  if (*ap!=0 && strchr("/abcdefghijklmnopqrstuvwxyz",**ap)==0)
  { if (strcmp(*ap,"-")!=0)
    { gp->has_constant = 1;
      if (!prior_parse(&gp->constant,*ap)) usage(4);	/* const-part */
    }
    ap += 1;
  }

  if (*ap!=0 && strchr("/abcdefghijklmnopqrstuvwxyz",**ap)==0)
  { if (strcmp(*ap,"-")!=0)
    { gp->has_linear = 1;
      if (!prior_parse(&gp->linear,*ap)) usage(5);		/* linear-part */
    }
    ap += 1;
  }

  if (*ap!=0 && strchr("/abcdefghijklmnopqrstuvwxyz",**ap)==0)
  { if (strcmp(*ap,"-")!=0)
    { gp->has_jitter = 1;
      if (!prior_parse(&gp->jitter,*ap)) usage(6);		/* jitter-part */
    }
    ap += 1;
  }

  need_spread = 0;

  while (*ap!=0 && strchr("abcdefghijklmnopqrstuvwxyz",**ap))
  {
    if (*ap!=0 && strncmp(*ap,"omit",4)==0)
    { parse_flags (*ap+4, gp->linear_flags, gp->N_inputs, Flag_omit);
    }
    else if (*ap!=0 && strncmp(*ap,"spread",4)==0)
    { parse_flags (*ap+6, gp->linear_flags, gp->N_inputs, Flag_spread);
      need_spread = 1;
    }
    else
    { fprintf(stderr,"Unknown linear flag argument: %s\n",*ap);
      exit(1);
    }

    ap += 1;
  }

  if (need_spread)
	{ gp->linear_spread = atoi(*ap);
    if (gp->linear_spread<=0) 
    { fprintf(stderr,"Need to specify spread width for linear part\n");
      exit(1);
    }
    ap += 1;
  }
 
  if (*ap!=0 && strcmp(*ap,"/")!=0) usage(7);

	l = 0;
	
	/* additional terms in the covariance function */

	/*	
		Zero or more additional terms in the covariance function may be
	specified using further groups of arguments.  A group for which
	"power" is absent or positive results in a term in the expression for
	the covariance between a particular output at inputs x and x' that has
	the form:
			v^2 * exp( - SUM_i (w_i |x_i - x'_i|)^R )
	The power, R, in this expression must be in the interval (0,2].  It is
	given by the last argument in a group, with the default being R=2.
	The first argument in the group gives the prior for the scale
	hyperparameter, v, which must have only one level.  The prior for the
	w_i, which determine the relevance of the various inputs, can have up
	to two levels, allowing for a common hyperparameter and for
	hyperparameters for each input, i.  Here again, the "x" option may be
	used to automatically scale the prior. 
	*/

  while (*ap!=0)
  {
    if (l==Max_exp_parts) 
    { fprintf(stderr,"Too many exponential parts in covariance (max %d)\n",
              Max_exp_parts);
      exit(1);
    }

    ap += 1;
		
		/* the covariance function: v^2 * exp( - SUM_i (w_i |x_i - x'_i|)^R ) */
    if (*ap==0 || !prior_parse(&gp->exp[l].scale,*ap++)) usage(8);			/* v: scale hyperparameter */
    if (*ap==0 || !prior_parse(&gp->exp[l].relevance,*ap++)) usage(9);  /* w_i: the relevance of the various inputs */

    gp->exp[l].power = 2; /* R: power */

    if (*ap!=0 && strcmp(*ap,"/")!=0 && strchr("0123456789.+-",**ap))
    { if ((gp->exp[l].power = atof(*ap++)) == 0 || gp->exp[l].power>2
       || gp->exp[l].power<0 && gp->exp[l].power!=-1) 
      { usage(10);
      }
    }

    need_spread = 0;
		
		/* delta, omit, spread */
    while (*ap!=0 && strchr("abcdefghijklmnopqrstuvwxyz",**ap))
    {
      if (*ap!=0 && strncmp(*ap,"delta",5)==0)
      { parse_flags (*ap+5, gp->exp[l].flags, gp->N_inputs, Flag_delta);
      }
      else if (*ap!=0 && strncmp(*ap,"omit",4)==0)
      { parse_flags (*ap+4, gp->exp[l].flags, gp->N_inputs, Flag_omit);
      }
      else if (*ap!=0 && strncmp(*ap,"spread",4)==0 && 0) /* Disabled */
      { parse_flags (*ap+6, gp->exp[l].flags, gp->N_inputs, Flag_spread);
        need_spread = 1;
      }
      else
      { fprintf(stderr,"Unknown flag argument: %s\n",*ap);
        exit(1);
      }

      ap += 1;
    }

    if (need_spread)
    { gp->exp[l].spread = atoi(*ap);
      if (gp->linear_spread<=0) 
      { fprintf(stderr,"Need to specify spread width\n");
        exit(1);
      }
      ap += 1;
      /* SPREAD IS DISABLED FOR NOW */
      fprintf (stderr,
        "The spread option is presently allowed only for the linear part\n");
      exit(1);
    }
 
    if (*ap!=0 && strcmp(*ap,"/")!=0) usage(11);

    l += 1;
  }

  gp->N_exp_parts = l;

  /* Check for illegal prior specifications. */

	if (gp->has_constant && (gp->constant.scale || gp->constant.alpha[1]!=0
                                              || gp->constant.alpha[2]!=0))
  { fprintf(stderr,"Illegal prior for constant part of covariance\n");
    exit(1); 
  }

  if (gp->has_jitter && (gp->jitter.scale || gp->jitter.alpha[1]!=0 
                                          || gp->jitter.alpha[2]!=0))
  { fprintf(stderr,"Illegal prior for jitter part of covariance\n");
    exit(1); 
  }

  if (gp->has_linear && gp->linear.alpha[2]!=0)
  { fprintf(stderr,"Illegal prior for linear part of covariance\n");
    exit(1); 
  }

	for (l = 0; l<gp->N_exp_parts; l++)
  { if (gp->exp[l].scale.scale || gp->exp[l].scale.alpha[1]!=0 || gp->exp[l].scale.alpha[2]!=0)
    { fprintf(stderr,"Illegal prior for scale in exp part of covariance\n");
			exit(1);
		}

		// a0:a1:a2=0:0:0
		if (gp->exp[l].relevance.alpha[0]==0 && gp->exp[l].relevance.alpha[1]==0 && gp->exp[l].relevance.alpha[2]==0)
		{ fprintf(stderr,"Illegal prior for relevance in exp part of covariance\n");
			exit(1);
		}

		// a0:a1:a2=0:1:1 or  a0:a1:a2=1:1:1
		if (gp->exp[l].relevance.alpha[1]==1 && gp->exp[l].relevance.alpha[2]==1)
		{ fprintf(stderr,"Illegal prior for relevance in exp part of covariance\n");
			exit(1);
		}

		if (gp->exp[l].relevance.alpha[2]!=0)
		{ fprintf(stderr,"relevance.alpha[2]=%f\n", gp->exp[l].relevance.alpha[2]);
		}

 		/*if (gp->exp[l].relevance.alpha[2]!=0)
		{ fprintf(stderr,"Illegal prior for relevance in exp part of covariance\n");
			exit(1);
    }*/
	}

  /* Create log file and write records. */

  log_file_create(&logf);

  logf.header.type = 'P';
  logf.header.index = -1;
  logf.header.size = sizeof *gp;
  log_file_append(&logf,gp);

	log_file_close(&logf);

  exit(0);
}


/* DISPLAY USAGE MESSAGE AND EXIT. */

static void usage(int id)
{	
	fprintf(stderr, "error: %d\n", id);	
  fprintf(stderr,
   "Usage: gp-spec log-file N-inputs N-outputs\n");
  fprintf(stderr,
   "         [ const-part [ linear-part [ jitter-part ] ] ] { flag } [ spread ] \n");
  fprintf(stderr,
   "         { / scale-prior relevance-prior [ power ] { flag } }\n");
  fprintf(stderr,
   "   or: gp-spec log-file (to display stored specifications)\n");
  fprintf(stderr,
   "Prior: [x]Width[:[Alpha-high][:[Alpha-low]]]\n");

  exit(1);
}

